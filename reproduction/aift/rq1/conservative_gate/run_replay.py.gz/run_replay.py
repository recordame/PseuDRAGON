"""Reroute frozen stores without rebuilding rules or calling a model."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT / "paper/experiments/rq1/20260929_reuse_growth_repaired_v2"
ARM = "all_selections_name_cache_rules"
FILES = ["protocol.json", "results.json", "snapshots.jsonl", "inputs/records.json",
         "inputs/groups.json", "inputs/schedules.json", "sources/heuristic_pattern_learner.py",
         "sources/expert_preference_manager.py", "replay_helpers.py"]


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def prepare():
    p = read(SOURCE / "protocol.json")
    for relative, expected in p["files"].items():
        assert sha(SOURCE / relative) == expected, relative
    current = ROOT / "paper/experiments/rq1/20261004_family_name_exclusion/sources/heuristic_pattern_learner.py"
    assert sha(current) == sha(SOURCE / "sources/heuristic_pattern_learner.py")
    write(HERE / "protocol.json", {
        "frozen_utc": datetime.now(timezone.utc).isoformat(),
        "status_at_freeze": "Existing default outcomes known; proposed conservative routes not calculated.",
        "source": str(SOURCE.relative_to(ROOT)),
        "source_files": {name: sha(SOURCE / name) for name in FILES},
        "runner_sha256": sha(Path(__file__)),
        "current_learner_sha256": sha(current),
        "arms": ["guarded_cache_rules", "defer_unseen_nonpii_rules"],
        "intervention": "Keep unanimous exact-name lookup and all PII rule routes. If the chosen learned rule labels a name absent from training as Non-PII, use exactly the archived fallback instead. Do not try a lower-priority rule.",
        "design": "Same 20 nested acquisition orders, 5 family holdouts, 3 fixed prediction sets and 0/25/50/75/100 percent. Independently route immutable saved stores; do not retrain or alter the learner.",
        "units": "92 columns per order/stage/prediction set; 20 orders and 3 sets are repeated views, not independent datasets.",
        "new_model_calls": 0, "new_participants": 0,
        "outcomes": ["reuse", "fallback", "added_FN_FP_relative_to_fixed_fallback", "total_FN_FP", "distinct_reused_names", "blocked_routes"],
        "criterion": "Report coverage loss and false-negative change together; no advance policy-success conclusion.",
    })


def independent_route(q, train, rules):
    baseline = {"prediction": q["fallback"], "route": "fallback", "pattern": None,
                "support_ids": [], "reason": "no_reuse"}
    same = [r for r in train if r["column"].lower() == q["column"].lower()]
    if same:
        labels = {r["label"] for r in same}
        if len(labels) != 1:
            return baseline | {"reason": "conflicting_exact_labels"}
        return baseline | {"prediction": next(iter(labels)), "route": "name_cache",
                           "support_ids": [r["id"] for r in same], "reason": "unanimous_exact_name"}
    for rule in sorted((r for r in rules if r.get("enabled", True)),
                       key=lambda r: r.get("priority", 0), reverse=True):
        if re.search(rule["regex"], q["column"].upper(), re.IGNORECASE):
            support = [r["id"] for r in train if r["column"].upper() in rule.get("sample_columns", [])]
            assert support
            return baseline | {"prediction": rule.get("pii_type", "PII") == "PII", "route": "rule",
                               "pattern": rule["regex"], "support_ids": support, "reason": "trained_rule"}
    return baseline


def metrics(rows, labels):
    c = Counter()
    for row in rows:
        gold, pred, fallback = labels[row["id"]], row["prediction"], row["fallback"]
        c["TP" if gold and pred else "FN" if gold else "FP" if pred else "TN"] += 1
        c["reused"] += row["route"] != "fallback"
        c["wrong_reuse"] += row["route"] != "fallback" and pred != gold
        c["fixed"] += pred == gold != fallback
        c["harmed"] += pred != gold == fallback
        c["added_FN"] += gold and fallback and not pred
        c["added_FP"] += not gold and not fallback and pred
        c["fallback_routes"] += row["route"] == "fallback"
        c["blocked_routes"] += row.get("blocked", False)
        c["positive_reuse"] += row["route"] != "fallback" and pred
        c["negative_reuse"] += row["route"] != "fallback" and not pred
    out = {key: c[key] for key in ("TP", "FN", "FP", "TN", "reused", "wrong_reuse", "fixed", "harmed", "added_FN", "added_FP", "fallback_routes", "blocked_routes", "positive_reuse", "negative_reuse")}
    out["F1"] = 2*c["TP"]/(2*c["TP"]+c["FP"]+c["FN"])
    out["distinct_reused_names"] = len({r["column"].upper() for r in rows if r["route"] != "fallback"})
    out["distinct_blocked_names"] = len({r["column"].upper() for r in rows if r.get("blocked")})
    return out


def run(name):
    protocol = read(HERE / "protocol.json")
    assert sha(Path(__file__)) == protocol["runner_sha256"]
    for relative, expected in protocol["source_files"].items():
        assert sha(SOURCE / relative) == expected, relative
    records = read(SOURCE / "inputs/records.json")
    by_id = {r["id"]: r for r in records}
    labels = {r["id"]: r["label"] for r in records}
    groups = read(SOURCE / "inputs/groups.json")["groups"]
    schedules = read(SOURCE / "inputs/schedules.json")
    archive = read(SOURCE / "results.json")
    archived_metrics = {(m["seed"], m["percentage"], m["repetition"]): m for m in archive["metrics"] if m["condition"] == ARM}
    collected = defaultdict(list)
    identity_checks = 0
    stores = 0
    for line in (SOURCE / "snapshots.jsonl").open():
        snap = json.loads(line)
        seed, pct, rep, group = (snap[k] for k in ("seed", "percentage", "repetition", "group"))
        schedule = schedules[str(seed)][group]
        expected_train = sorted(schedule["acquisition_order"][:schedule["prefix_sizes"][str(pct)]])
        assert expected_train == snap["training_ids"]
        train = [by_id[k] for k in expected_train]
        assert all(r["table"] not in groups[group] for r in train)
        names = {r["column"].upper() for r in train}
        for rule in snap["rules"]["heuristics"]:
            assert set(rule.get("sample_columns", [])) <= names
        rows = [r for r in snap["rows"] if r["condition"] == ARM]
        expected_queries = {r["id"] for r in records if r["table"] in groups[group]}
        assert {r["id"] for r in rows} == expected_queries
        for archived in rows:
            assert archived["fallback"] == by_id[archived["id"]]["fallbacks"][str(rep)]
            route = independent_route(archived, train, snap["rules"]["heuristics"])
            assert all(route[k] == archived[k] for k in route), (seed, pct, rep, group, archived["id"])
            base = {k: archived[k] for k in ("id", "column", "fallback")} | route
            collected[seed, pct, rep, "guarded_cache_rules"].append(base)
            candidate = dict(base)
            unseen = archived["column"].upper() not in names
            if route["route"] == "rule" and unseen and not route["prediction"]:
                candidate.update(prediction=archived["fallback"], route="fallback", pattern=None,
                                 support_ids=[], reason="deferred_unseen_nonpii_rule", blocked=True)
            collected[seed, pct, rep, "defer_unseen_nonpii_rules"].append(candidate)
            identity_checks += 1
        stores += 1
    all_metrics = []
    for (seed, pct, rep, arm), rows in sorted(collected.items()):
        assert len(rows) == len({r["id"] for r in rows}) == 92
        m = metrics(rows, labels)
        if arm == "guarded_cache_rules":
            old = archived_metrics[seed, pct, rep]
            for key in ("TP", "FN", "FP", "TN", "reused", "wrong_reuse", "fixed", "harmed", "F1", "fallback_routes"):
                assert m[key] == old[key], (seed, pct, rep, key)
        all_metrics.append(dict(seed=seed, percentage=pct, repetition=rep, arm=arm, **m))
    def summarize(items):
        return {key: {"mean": statistics.mean([m[key] for m in items]), "min": min(m[key] for m in items), "max": max(m[key] for m in items)} for key in items[0] if key not in {"seed", "percentage", "repetition", "arm"}}
    summary = []
    for arm in protocol["arms"]:
        for pct in (0, 25, 50, 75, 100):
            selected = [m for m in all_metrics if m["arm"] == arm and m["percentage"] == pct]
            summary.append(dict(arm=arm, percentage=pct, views=len(selected), pooled=summarize(selected),
                                by_fixed_prediction_set={str(rep): summarize([m for m in selected if m["repetition"] == rep]) for rep in (1, 2, 3)}))
    write(HERE / (name + "-routes.json"), [{"seed": k[0], "percentage": k[1], "repetition": k[2], "arm": k[3], "rows": v} for k, v in sorted(collected.items())])
    write(HERE / (name + "-results.json"), {"protocol_sha256": sha(HERE / "protocol.json"),
          "default_route_identity_checks": identity_checks, "default_metric_groups_matched": len(archived_metrics),
          "frozen_stores_checked": stores, "summary": summary, "metrics": all_metrics,
          "new_model_calls": 0, "new_participants": 0,
          "frozen_sources_preserved": all(sha(SOURCE / rel) == value for rel, value in protocol["source_files"].items())})
    print(json.dumps({"stores": stores, "route_identity_checks": identity_checks, "metric_groups": len(all_metrics)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "first", "repeat"))
    args = parser.parse_args()
    prepare() if args.command == "prepare" else run(args.command)
