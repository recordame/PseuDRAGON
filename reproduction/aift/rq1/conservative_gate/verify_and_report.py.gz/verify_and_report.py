"""Check the intervention directly against archived rows and raw labels."""
import hashlib
import json
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
protocol = read(HERE / "protocol.json")
source = ROOT / protocol["source"]
records = read(source / "inputs/records.json")
labels = {r["id"]: r["label"] for r in records}
by_id = {r["id"]: r for r in records}
groups = {(g["seed"], g["percentage"], g["repetition"], g["arm"]): g["rows"]
          for g in read(HERE / "first-routes.json")}
training = {}
archived = {}
for line in (source / "snapshots.jsonl").open():
    snap = json.loads(line)
    for r in snap["rows"]:
        if r["condition"] != "all_selections_name_cache_rules":
            continue
        key = (snap["seed"], snap["percentage"], snap["repetition"], r["id"])
        archived[key] = r
        training[key] = {by_id[k]["column"].casefold() for k in snap["training_ids"]}

metrics = read(HERE / "first-results.json")["metrics"]
for m in metrics:
    rows = groups[m["seed"], m["percentage"], m["repetition"], m["arm"]]
    for r in rows:
        key = (m["seed"], m["percentage"], m["repetition"], r["id"])
        old = archived[key]
        eligible = (old["route"] == "rule" and not old["prediction"]
                    and r["column"].casefold() not in training[key])
        should_block = m["arm"] == "defer_unseen_nonpii_rules" and eligible
        assert bool(r.get("blocked")) == should_block
        assert r["prediction"] == (old["fallback"] if should_block else old["prediction"])
        assert r["route"] == ("fallback" if should_block else old["route"])
        assert old["route"] != "name_cache" or r["route"] == "name_cache"
    y = [(labels[r["id"]], r["prediction"], r["fallback"]) for r in rows]
    assert m["FN"] == sum(gold and not pred for gold, pred, _ in y)
    assert m["FP"] == sum(not gold and pred for gold, pred, _ in y)
    assert m["added_FN"] == sum(gold and fallback and not pred for gold, pred, fallback in y)
    assert m["added_FP"] == sum(not gold and not fallback and pred for gold, pred, fallback in y)
    assert m["reused"] == sum(r["route"] != "fallback" for r in rows)
    assert m["fallback_routes"] == 92 - m["reused"]
    assert m["distinct_reused_names"] == len({r["column"].casefold() for r in rows if r["route"] != "fallback"})
result = read(HERE / "first-results.json")
for s in result["summary"]:
    selected = [m for m in metrics if m["arm"] == s["arm"] and m["percentage"] == s["percentage"]]
    assert len(selected) == 60
    for key, bounds in s["pooled"].items():
        values = [m[key] for m in selected]
        assert bounds == dict(mean=mean(values), min=min(values), max=max(values))
for kind in ("routes", "results"):
    assert (HERE / f"first-{kind}.json").read_bytes() == (HERE / f"repeat-{kind}.json").read_bytes()
assert all(sha(source / relative) == value for relative, value in protocol["source_files"].items())
checks = {"status": "pass", "archived_route_bindings": len(archived),
          "intervention_decisions_verified": sum(len(rows) for rows in groups.values()),
          "metric_groups_verified": len(metrics), "exact_name_cache_preserved": True,
          "immutable_source_hashes_preserved": True, "first_repeat_identical": True,
          "verification_type": "Separate calculation and archived-row intervention audit; same author, not external independent review.",
          "first_results_sha256": sha(HERE / "first-results.json"),
          "first_routes_sha256": sha(HERE / "first-routes.json")}
out = HERE / "verification.json"
assert not out.exists()
out.write_text(json.dumps(checks, indent=2) + "\n")
lines = ["# Conservative non-PII rule replay", "", "All inputs, stores, rules, and model outputs stay fixed. No new model or participant calls.", "", "Current exact-name cache routes are preserved. Only a learned Non-PII rule for a name absent from its training store is deferred to the same archived fallback.", "", "Each row below averages 20 frozen acquisition orders and three fixed prediction sets on the same 92 columns. These are repeated views, not independent samples.", "", "| Knowledge % | Default reuse | Candidate reuse | Default fallback | Candidate fallback | Default added FN: mean / worst | Candidate added FN | Default names / candidate names |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
for pct in (0, 25, 50, 75, 100):
    a = next(s["pooled"] for s in result["summary"] if s["arm"] == "guarded_cache_rules" and s["percentage"] == pct)
    b = next(s["pooled"] for s in result["summary"] if s["arm"] == "defer_unseen_nonpii_rules" and s["percentage"] == pct)
    lines.append(f"| {pct} | {a['reused']['mean']:.2f} | {b['reused']['mean']:.2f} | {a['fallback_routes']['mean']:.2f} | {b['fallback_routes']['mean']:.2f} | {a['added_FN']['mean']:.2f} / {a['added_FN']['max']} | {b['added_FN']['mean']:.2f} | {a['distinct_reused_names']['mean']:.2f} / {b['distinct_reused_names']['mean']:.2f} |")
lines += ["", "Added FP is zero in both arms at every stage. Candidate wrong reuse is zero at every stage. Total FP remains 0, 0, and 1 across the three fixed prediction sets because the intervention leaves that fallback error unchanged.", "", "At 25%, orders 7 and 19 each wrongly reuse Non-PII labels for the two WD_ACNO columns in CD_TRNS_TRAN and HF_TRNS_TRAN in all three fixed sets. Deferral removes all 12 repeated additional-FN events. The cost is an average 10.85 more fallback routes per view (range 1–18). This is two error-producing acquisition orders and one column name, not twelve independent failures.", "", "At full knowledge the candidate keeps 77 routes, retaining both unseen-name positive reuses while deferring six correct unseen-name negative reuses. It therefore trades coverage for a conservative route on these observed inputs; it does not dominate the default or establish universal privacy protection. The unchanged default has no added reuse errors from 50% onward.", "", "Default rerouting matches all 27,600 archived route/pattern/support records and 300 metric groups. Separate audit checks 55,200 paired decisions. First and repeat outputs are byte-identical; source hashes remain unchanged.", "", "No manuscript, learner, product, raw input, or Git change was made. Results are a candidate comparison for user judgment, not a new policy recommendation already adopted."]
report = HERE / "report.md"
assert not report.exists()
report.write_text("\n".join(lines) + "\n")
print(json.dumps(checks))
