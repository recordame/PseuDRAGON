#!/usr/bin/env python3
"""Compare three reuse routes under identical, explicitly managed approvals."""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import logging
import re
import shutil
import statistics
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
logging.disable(logging.CRITICAL)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PRIOR = HERE.parent / "20260929_reuse_component_ablation_final"
GUARD = HERE.parent / "20260930_history_conflict_guard"
ARMS = ("exact_cache", "guarded_history_rules", "guarded_cache_rules")
STAGES = ("clean", "wrong_approval", "withdrawn_rebuilt", "corrected_rebuilt")
VOLATILE = {"created_at", "updated_at", "last_updated", "timestamp"}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe_path(path):
    path = Path(path).resolve()
    assert path.is_relative_to(HERE), str(path)
    return path


def write(path, value):
    path = safe_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def journal(event, **data):
    with (HERE / "journal.jsonl").open("a") as stream:
        stream.write(json.dumps({"utc": datetime.now(timezone.utc).isoformat(),
                                 "event": event, **data}) + "\n")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def semantic(value):
    if isinstance(value, dict):
        return {key: semantic(item) for key, item in value.items() if key not in VOLATILE}
    if isinstance(value, list):
        return [semantic(item) for item in value]
    return value


def semantic_digest(value):
    data = json.dumps(semantic(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(data.encode()).hexdigest()


def prepare():
    assert not (HERE / "protocol.json").exists(), "Never overwrite a frozen protocol"
    manifest = {}

    def register(path):
        path = Path(path).resolve()
        manifest[str(path)] = sha(path)
        return path

    source_names = ("guarded_expert_preference_manager.py", "heuristic_pattern_learner.py",
                    "canonical_pure_lookup.py")
    for name in source_names:
        source = register(GUARD / "sources" / name)
        destination = HERE / "sources" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    for name in ("records.json", "groups.json"):
        source = register(GUARD / "inputs" / name)
        destination = HERE / "inputs" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    records = read(HERE / "inputs/records.json")
    groups = read(HERE / "inputs/groups.json")["groups"]
    prior_cases = read(register(PRIOR / "cases.json"))
    register(PRIOR / "protocol.json")
    register(GUARD / "protocol.json")
    assert len(records) == 92 and sum(row["label"] for row in records) == 32
    assert records == sorted(records, key=lambda row: row["id"])
    assert len(prior_cases) == 1104
    clean = []
    for rep in (1, 2, 3):
        for group in groups:
            folder = PRIOR / "stores" / f"r{rep}" / group / "clean"
            clean.append({"rep": rep, "group": group,
                          "feedback": read(register(folder / "feedback.json")),
                          "archived_rules": read(register(folder / "heuristics.json"))["heuristics"]})
    write(HERE / "inputs/clean_stores.json", clean)
    with (HERE / "inputs/case_stores.jsonl").open("w") as output:
        for case in prior_cases:
            folder = PRIOR / case["store_directory"]
            row = {key: case[key] for key in ("case", "rep", "group", "injected_id", "true_label")}
            row.update(
                damaged_feedback=read(register(folder / "corrupted_feedback.json")),
                archived_damaged_rules=read(register(folder / "corrupted_rules.json")),
                remaining_feedback=read(register(folder / "fresh_without_record/feedback.json")),
                archived_remaining_rules=read(register(folder / "fresh_without_record/heuristics.json"))["heuristics"],
                provenance_directory=str(folder),
            )
            output.write(json.dumps(row, ensure_ascii=False) + "\n")
    write(HERE / "input_manifest.json", manifest)
    files = {str(path.relative_to(HERE)): sha(path)
             for path in HERE.rglob("*") if path.is_file() and path.name != "journal.jsonl"}
    protocol = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "Frozen before new routing, learner execution, or outcome aggregation",
        "study": "Equal-maintenance exact cache versus guarded history and learned-rule reuse",
        "prior_awareness": "Earlier clean endpoints 75/75/83 and guarded rule-arm corruption outcomes of 2 harmful cases / 4 added errors per prediction set are known. This study must not present those inherited outcomes as newly discovered. The fully managed exact-cache comparison and complete event-stage stratification have not been computed here before freeze.",
        "arms": list(ARMS), "stages": list(STAGES), "prediction_sets": [1, 2, 3],
        "groups": groups, "records": 92, "positive_records": 32,
        "cases": "368 fold/training-record positions per fixed prediction set; 1104 cases total. Each training position is changed independently, rather than combining all injected errors into one store.",
        "training": "Identical existing reference-confirmed records in canonical table.column order, same five family split, and identical three archived fresh-prediction fallbacks. Held-out query dictionaries omit scoring labels and actions. No new approvals or inference.",
        "events": [
            "clean: install all reference-confirmed training selections and rebuild rules from an empty rule list",
            "wrong_approval: replace exactly one training label with its opposite; retain other labels, metadata, treatment actions, ordering, and frozen predictions; install the existing reconstructed feedback and actually rebuild in the working store",
            "withdrawn_rebuilt: remove the entire wrong approval record; install feedback reconstructed from the remaining original records; actually rebuild in the same working store",
            "corrected_rebuilt: restore the removed record with its original correct label; install full clean feedback and actually rebuild in the same working store"
        ],
        "shared_active_view": "Before all three arms, exclude column_exact entries with total_selections <= 0. Active votes are the pii_type of positive-count exact selections and only the current classification of each pii_classification entry. Historical old/new arrays are never votes. Current corrections must agree with at least one currently active record label for that name. The name-label sets in this common view must exactly match the active record ledger. Canonical pure lookup and guarded history lookup both receive this same filtered view.",
        "common_guard": "The archived _has_active_name_label_conflict function is used for every arm. More than one current valid label for the query name forces the identical frozen fallback and skips both exact lookup and rules.",
        "exact_cache": "After the common guard, use the archived canonical pure exact lookup over all current approvals, then the fixed fallback; no learned patterns. It supports the same record replacement, withdrawal, and restoration. Cache entries reflect current active approvals at each event; no stale or last-write baseline is used.",
        "guarded_history_rules": "After the common guard, use the archived guarded correction-history lookup, then the unchanged repaired production rule classifier, then fixed fallback.",
        "guarded_cache_rules": "After the common guard, use the exact_cache lookup, then the same actual rule list and rule classifier as guarded_history_rules, then fixed fallback.",
        "actual_rebuild": "Use byte-copied production learner and trigger_pattern_learning at every event, persisting actual rule lists. Compare the withdrawn endpoint with the archived independently fitted remaining-record snapshot and the restored endpoint with this run's clean endpoint. Never substitute the archived oracle for an actual rebuild. Cache-only ignores derived rules but receives identical active feedback updates.",
        "thresholds": {"MAX_CONFLICT_RATE": 0.10, "MIN_PATTERN_OCCURRENCES": 2, "MIN_CONFIDENCE": 0.8},
        "metrics": {
            "correct_reuse": "Stored-route output equals the separate scoring reference.",
            "wrong_reuse": "Stored-route output differs from the separate scoring reference.",
            "harmed_vs_clean": "Wrong output where this arm's original full-clean output was correct.",
            "harmed_vs_fallback": "Wrong output where the shared frozen fallback was correct.",
            "unseen_names": "Primary seen/unseen strata use the original clean training-name set. Also save active-state seen/unseen, since withdrawing a unique record can make a formerly seen name absent.",
            "residual_reuse": "At the withdrawn endpoint, a stored route whose prediction/route/pattern/reason differs from the fresh remaining-record oracle; this is not merely a regex that also matches the removed name.",
            "fair_pairing": "Count extra correct/wrong stored routes and prediction harm relative to the equally maintained exact_cache at each stage; equal lifecycle restoration is a shared property, not superiority.",
            "units": "Report clean 92-field endpoints separately from repeated query-case events. Cases are not independent human mistakes, datasets, or unique columns."
        },
        "checks": ["shared feedback, rule list, fallback, and query inputs across arms", "one flipped record per case", "all training records exclude query family", "active-view vote sets equal active record ledger", "no zero-count or history-only votes", "actual rules have supporting names from retained training records", "clean endpoints reproduce 75/75/83 known counts", "withdrawn route equality with independently fitted fresh remaining store", "restored route equality with clean endpoint", "complete repeated run has identical semantic outputs", "all frozen input/source hashes remain unchanged"],
        "repeat": "Execute all cases twice. Compare semantic JSON outputs, excluding only created_at, updated_at, last_updated, and timestamp fields inside raw actual rules. Runtime metadata is separate; execution times are not operational LLM latency.",
        "scope": "One institution, synthetic/reconstructed schemas, fixed recorded predictions, single label corruption. No policy-scope drift, treatments, embeddings, static/manual rules, privacy resistance, participant study, transactional product withdrawal endpoint, or new model training. No manuscript or product changes.",
        "failure_policy": "Preserve all failures and do not tune thresholds or introduce new reuse routes after seeing results. Equal managed-cache outcomes are not a superiority claim. Invalid protocol/code requires an explicit dated amendment and a separate run directory, never silent overwrite.",
        "frozen_files": files,
    }
    write(HERE / "protocol.json", protocol)
    journal("protocol_frozen", protocol_sha256=sha(HERE / "protocol.json"),
            source_input_files=len(manifest), cases=len(prior_cases))
    print(json.dumps({"event": "protocol_frozen", "sha256": sha(HERE / "protocol.json"),
                      "source_input_files": len(manifest), "cases": len(prior_cases)}), flush=True)


def active_view(feedback):
    result = copy.deepcopy(feedback)
    result["column_exact"] = {
        key: entry for key, entry in result.get("column_exact", {}).items()
        if entry.get("total_selections", 1) > 0
    }
    return result


def active_votes(feedback):
    result = {}
    for section, label_key in (("column_exact", "pii_type"), ("pii_classification", "classification")):
        for key, entry in feedback.get(section, {}).items():
            if section == "column_exact" and entry.get("total_selections", 1) <= 0:
                continue
            name = entry.get("column_name", key.rsplit(":", 1)[0]).casefold()
            label = entry.get(label_key)
            assert label in {"PII", "Non-PII"}
            result.setdefault(name, set()).add(label == "PII")
    return result


def validate_feedback(feedback, ledger):
    actual = active_votes(active_view(feedback))
    expected = {}
    for record in ledger:
        expected.setdefault(record["column"].casefold(), set()).add(record["label"])
    assert actual == expected, (actual, expected)
    assert all(entry["classification"] in {"PII", "Non-PII"}
               for entry in feedback.get("pii_classification", {}).values())
    return actual


def compact_rules(rules):
    return semantic(rules)


def route_key(row):
    return {key: row[key] for key in ("id", "prediction", "route", "pattern", "reason")}


def measure(rows, clean, labels, queries):
    before = {row["id"]: row for row in clean}
    query_by_id = {row["id"]: row for row in queries}
    reused = [row for row in rows if row["route"] != "fallback"]
    wrong = [row for row in rows if row["prediction"] != labels[row["id"]]]
    harms = [row["id"] for row in wrong if before[row["id"]]["prediction"] == labels[row["id"]]]
    wrong_reuse = [row["id"] for row in reused if row["prediction"] != labels[row["id"]]]
    unseen = [row for row in reused if not row["seen_name_clean"]]
    active_unseen = [row for row in reused if not row["seen_name_active"]]
    return {
        "n": len(rows), "reused": len(reused), "correct_reuse": len(reused) - len(wrong_reuse),
        "wrong_reuse": len(wrong_reuse), "wrong_reuse_ids": wrong_reuse,
        "errors": len(wrong), "harmed_vs_clean": len(harms), "harmed_ids": harms,
        "harmed_vs_fallback": sum(row["prediction"] != labels[row["id"]]
                                  and query_by_id[row["id"]]["fallback"] == labels[row["id"]] for row in rows),
        "corrected_vs_fallback": sum(row["prediction"] == labels[row["id"]]
                                     and query_by_id[row["id"]]["fallback"] != labels[row["id"]] for row in rows),
        "conflict_fallbacks": sum(row["reason"] == "active_name_conflict" for row in rows),
        "unseen_name_reuse": len(unseen),
        "unseen_name_correct_reuse": sum(row["prediction"] == labels[row["id"]] for row in unseen),
        "unseen_name_wrong_reuse": sum(row["prediction"] != labels[row["id"]] for row in unseen),
        "active_unseen_name_reuse": len(active_unseen),
        "active_unseen_name_wrong_reuse": sum(row["prediction"] != labels[row["id"]] for row in active_unseen),
        "routes": dict(Counter(row["route"] for row in rows)),
    }


def paired_metrics(rows, cache, labels):
    baseline = {row["id"]: row for row in cache}
    extra = [row for row in rows if row["route"] != "fallback" and baseline[row["id"]]["route"] == "fallback"]
    lost = [row for row in rows if row["route"] == "fallback" and baseline[row["id"]]["route"] != "fallback"]
    return {
        "extra_correct_reuse": sum(row["prediction"] == labels[row["id"]] for row in extra),
        "extra_wrong_reuse": sum(row["prediction"] != labels[row["id"]] for row in extra),
        "extra_correct_reuse_ids": [row["id"] for row in extra if row["prediction"] == labels[row["id"]]],
        "extra_wrong_reuse_ids": [row["id"] for row in extra if row["prediction"] != labels[row["id"]]],
        "lost_reuse": len(lost),
        "harm_vs_cache": sum(row["prediction"] != labels[row["id"]]
                             and baseline[row["id"]]["prediction"] == labels[row["id"]] for row in rows),
        "benefit_vs_cache": sum(row["prediction"] == labels[row["id"]]
                                and baseline[row["id"]]["prediction"] != labels[row["id"]] for row in rows),
        "predictions_equal_cache": all(row["prediction"] == baseline[row["id"]]["prediction"] for row in rows),
    }


def aggregate(values):
    numeric = [key for key, value in values[0].items() if isinstance(value, int) and not isinstance(value, bool)]
    result = {key: sum(row[key] for row in values) for key in numeric}
    for key in ("harmed_vs_clean", "wrong_reuse", "extra_wrong_reuse", "harm_vs_cache"):
        if key in values[0]:
            result["cases_with_" + key] = sum(row[key] > 0 for row in values)
            result["max_" + key] = max(row[key] for row in values)
    if "predictions_equal_cache" in values[0]:
        result["cases_predictions_equal_cache"] = sum(row["predictions_equal_cache"] for row in values)
    return result


def run(run_name):
    target = safe_path(HERE / "runs" / run_name)
    assert not target.exists(), "Never overwrite an existing run"
    protocol = read(HERE / "protocol.json")
    for rel, digest in protocol["frozen_files"].items():
        assert sha(HERE / rel) == digest, rel
    manifest = read(HERE / "input_manifest.json")
    for path, digest in manifest.items():
        assert sha(path) == digest, path
    target.mkdir(parents=True)
    started = time.perf_counter()
    journal("run_started", run=run_name, protocol_sha256=sha(HERE / "protocol.json"))
    manager_module = load_module("equal_maintenance_manager", HERE / "sources/guarded_expert_preference_manager.py")
    learner_module = load_module("equal_maintenance_learner", HERE / "sources/heuristic_pattern_learner.py")
    lookup_module = load_module("equal_maintenance_lookup", HERE / "sources/canonical_pure_lookup.py")
    Manager = manager_module.ExpertPreferenceManager
    Learner = learner_module.HeuristicPatternLearner
    assert Learner.MIN_PATTERN_OCCURRENCES == 2
    assert Learner.MIN_CONFIDENCE == .8 and Learner.MAX_CONFLICT_RATE == .1

    def manager(feedback, rules, folder=None):
        obj = Manager.__new__(Manager)
        obj.preferences = active_view(feedback)
        obj.rag_system = None
        obj._column_embeddings = {}
        obj._embedding_generator = None
        if folder is None:
            learner = Learner.__new__(Learner)
            learner._load_heuristics = lambda: {"version": "2.0", "heuristics": copy.deepcopy(rules)}
        else:
            folder = safe_path(folder)
            folder.mkdir(parents=True)
            obj.preference_file = str(folder / "feedback.json")
            learner = Learner(obj.preference_file, str(folder / "heuristics.json"))
            obj._save_preferences()
            learner._save_heuristics({"version": "2.0", "heuristics": copy.deepcopy(rules), "statistics": {}})
        obj._heuristic_learner = learner
        return obj

    def rebuild(obj, feedback, ledger):
        validate_feedback(feedback, ledger)
        obj.preferences = active_view(feedback)
        obj._save_preferences()
        assert obj.trigger_pattern_learning() is not None
        rules = read(obj._heuristic_learner.heuristics_file)["heuristics"]
        retained_names = {row["column"].upper() for row in ledger}
        for rule in rules:
            assert rule.get("source") == "auto_learned"
            assert set(rule.get("sample_columns", [])).issubset(retained_names)
        return rules

    def routes(feedback, rules, ledger, queries, clean_names):
        validate_feedback(feedback, ledger)
        obj = manager(feedback, rules)
        active_names = {row["column"].casefold() for row in ledger}
        output = {arm: [] for arm in ARMS}
        for query in queries:
            assert "label" not in query and "action" not in query
            name = query["column"].casefold()
            exact_supports = [row for row in ledger if row["column"].casefold() == name]
            conflict = obj._has_active_name_label_conflict(query["column"])
            assert conflict == (len({row["label"] for row in exact_supports}) > 1)
            for arm in ARMS:
                row = {"id": query["id"], "prediction": query["fallback"], "route": "fallback",
                       "pattern": None, "reason": "no_stored_match", "support_ids": [],
                       "seen_name_clean": name in clean_names, "seen_name_active": name in active_names}
                if conflict:
                    assert obj.get_learned_pii_classification(query["column"], query["comment"]) is None
                    assert obj.classify_by_heuristics(query["column"], query["comment"]) is None
                    row.update(reason="active_name_conflict", support_ids=[item["id"] for item in exact_supports])
                    output[arm].append(row)
                    continue
                if arm == "guarded_history_rules":
                    answer = obj.get_learned_pii_classification(query["column"], query["comment"])
                else:
                    answer = lookup_module.get_learned_pii_classification(obj, query["column"], query["comment"])
                if answer is not None:
                    assert answer["match_type"] == "exact"
                    row.update(prediction=answer["classification"] == "PII",
                               route="history" if arm == "guarded_history_rules" else "name_cache",
                               reason="exact_correction_history" if arm == "guarded_history_rules" else "unanimous_active_approval",
                               support_ids=[item["id"] for item in exact_supports])
                elif arm != "exact_cache":
                    answer = obj.classify_by_heuristics(query["column"], query["comment"])
                    if answer is not None:
                        matching = [rule for rule in sorted(rules, key=lambda item: item.get("priority", 0), reverse=True)
                                    if rule.get("enabled", True) and rule["regex"] == answer["pattern"]]
                        assert matching
                        support_names = {value.casefold() for value in matching[0].get("sample_columns", [])}
                        row.update(prediction=answer["classification"] == "PII", route="rule", pattern=answer["pattern"],
                                   reason="learned_pattern", support_ids=[item["id"] for item in ledger
                                                                       if item["column"].casefold() in support_names])
                output[arm].append(row)
        return output

    records = read(HERE / "inputs/records.json")
    labels = {row["id"]: row["label"] for row in records}
    groups = protocol["groups"]
    clean_inputs = {(row["rep"], row["group"]): row for row in read(HERE / "inputs/clean_stores.json")}
    clean_routes, clean_rules, ledgers, queries_by_fold, clean_names_by_fold = {}, {}, {}, {}, {}
    baseline_rows = []
    for rep in protocol["prediction_sets"]:
        for group, tables in groups.items():
            key = rep, group
            ledger = [dict(row, fallback=row["fallbacks"][str(rep)]) for row in records if row["table"] not in tables]
            queries = [{field: row[field] for field in ("id", "table", "column", "comment")}
                       | {"fallback": row["fallbacks"][str(rep)]} for row in records if row["table"] in tables]
            assert len(ledger) + len(queries) == 92
            assert not {row["table"] for row in ledger}.intersection(tables)
            names = {row["column"].casefold() for row in ledger}
            feedback = clean_inputs[key]["feedback"]
            obj = manager(feedback, [], target / "stores" / f"r{rep}" / group / "clean")
            rules = rebuild(obj, feedback, ledger)
            route = routes(feedback, rules, ledger, queries, names)
            reference = routes(feedback, clean_inputs[key]["archived_rules"], ledger, queries, names)
            assert route == reference
            clean_routes[key], clean_rules[key] = route, rules
            ledgers[key], queries_by_fold[key], clean_names_by_fold[key] = ledger, queries, names
            baseline_rows.append({"rep": rep, "group": group, "queries": queries, "train_ids": [row["id"] for row in ledger],
                                  "routes": route, "actual_rules": compact_rules(rules),
                                  "metrics": {arm: measure(route[arm], route[arm], labels, queries) for arm in ARMS},
                                  "paired_vs_cache": {arm: paired_metrics(route[arm], route["exact_cache"], labels) for arm in ARMS}})
    write(target / "baseline_routes.json", baseline_rows)
    clean_summary = {str(rep): {arm: aggregate([row["metrics"][arm] for row in baseline_rows if row["rep"] == rep])
                               for arm in ARMS} for rep in protocol["prediction_sets"]}
    for value in clean_summary.values():
        assert [value[arm]["reused"] for arm in ARMS] == [75, 75, 83]
        assert all(value[arm]["wrong_reuse"] == 0 for arm in ARMS)
    journal("clean_endpoints_verified", run=run_name, reuse=[75, 75, 83])
    print(json.dumps({"event": "clean_endpoints_verified", "run": run_name, "reuse": [75, 75, 83]}), flush=True)

    results = []
    with (HERE / "inputs/case_stores.jsonl").open() as inputs, (target / "case_routes.jsonl").open("w") as output:
        for index, text in enumerate(inputs):
            case = json.loads(text)
            rep, group = case["rep"], case["group"]
            key = rep, group
            clean_ledger = ledgers[key]
            queries = queries_by_fold[key]
            clean_names = clean_names_by_fold[key]
            corrupted = [dict(row, label=not row["label"]) if row["id"] == case["injected_id"] else dict(row)
                         for row in clean_ledger]
            remaining = [dict(row) for row in clean_ledger if row["id"] != case["injected_id"]]
            assert sum(left["label"] != right["label"] for left, right in zip(clean_ledger, corrupted)) == 1
            assert len(remaining) == len(clean_ledger) - 1
            state_ledgers = {"clean": clean_ledger, "wrong_approval": corrupted,
                             "withdrawn_rebuilt": remaining, "corrected_rebuilt": clean_ledger}
            state_feedback = {"clean": clean_inputs[key]["feedback"], "wrong_approval": case["damaged_feedback"],
                              "withdrawn_rebuilt": case["remaining_feedback"], "corrected_rebuilt": clean_inputs[key]["feedback"]}
            obj = manager(state_feedback["clean"], clean_rules[key], target / "stores" / f"case{index:04d}")
            actual_rules = {"clean": clean_rules[key]}
            states = {"clean": clean_routes[key]}
            for stage in STAGES[1:]:
                rule_list = rebuild(obj, state_feedback[stage], state_ledgers[stage])
                actual_rules[stage] = rule_list
                states[stage] = routes(state_feedback[stage], rule_list, state_ledgers[stage], queries, clean_names)
            archived_damaged = routes(case["damaged_feedback"], case["archived_damaged_rules"], corrupted, queries, clean_names)
            fresh_remaining = routes(case["remaining_feedback"], case["archived_remaining_rules"], remaining, queries, clean_names)
            assert states["wrong_approval"] == archived_damaged
            withdrawn_equal = {arm: states["withdrawn_rebuilt"][arm] == fresh_remaining[arm] for arm in ARMS}
            restored_equal = {arm: states["corrected_rebuilt"][arm] == clean_routes[key][arm] for arm in ARMS}
            residual = {}
            for arm in ARMS:
                fresh = {row["id"]: row for row in fresh_remaining[arm]}
                residual[arm] = {"residual_reuse": sum(row["route"] != "fallback" and route_key(row) != route_key(fresh[row["id"]])
                                                     for row in states["withdrawn_rebuilt"][arm]),
                                 "residual_prediction_changes": sum(row["prediction"] != fresh[row["id"]]["prediction"]
                                                                    for row in states["withdrawn_rebuilt"][arm]),
                                 "residual_harm": sum(row["prediction"] != labels[row["id"]] and fresh[row["id"]]["prediction"] == labels[row["id"]]
                                                      for row in states["withdrawn_rebuilt"][arm])}
            target_record = next(row for row in clean_ledger if row["id"] == case["injected_id"])
            wrong_votes = validate_feedback(case["damaged_feedback"], corrupted)
            injection_kind = "same_name_conflict" if len(wrong_votes[target_record["column"].casefold()]) > 1 else "wrong_approval_without_conflict"
            detail = {"case": case["case"], "rep": rep, "group": group, "injected_id": case["injected_id"],
                      "injection_kind": injection_kind, "true_label": case["true_label"], "query_n": len(queries),
                      "metrics": {stage: {arm: measure(states[stage][arm], clean_routes[key][arm], labels, queries)
                                           for arm in ARMS} for stage in STAGES},
                      "paired_vs_cache": {stage: {arm: paired_metrics(states[stage][arm], states[stage]["exact_cache"], labels)
                                                  for arm in ARMS} for stage in STAGES},
                      "withdrawn_equals_fresh": withdrawn_equal, "restored_equals_clean": restored_equal,
                      "residual": residual}
            results.append(detail)
            raw = {"case": case["case"], "rep": rep, "group": group, "injected_id": case["injected_id"],
                   "injection_kind": injection_kind, "queries": queries,
                   "active_approvals": {stage: [{field: row[field] for field in ("id", "table", "column", "label")}
                                                 for row in state_ledgers[stage]] for stage in STAGES},
                   "stages": states, "fresh_remaining": fresh_remaining,
                   "actual_rules": {stage: compact_rules(rule_list) for stage, rule_list in actual_rules.items()}}
            output.write(json.dumps(raw, ensure_ascii=False) + "\n")
            if (index + 1) % 100 == 0 or index + 1 == 1104:
                journal("progress", run=run_name, cases=index + 1)
                print(json.dumps({"event": "progress", "run": run_name, "cases": index + 1, "total": 1104}), flush=True)
    assert len(results) == 1104
    expected = {(rep, group, row["id"]) for rep in protocol["prediction_sets"]
                for group, tables in groups.items() for row in records if row["table"] not in tables}
    assert {(row["rep"], row["group"], row["injected_id"]) for row in results} == expected
    write(target / "cases.json", results)
    summary = {
        "protocol_sha256": sha(HERE / "protocol.json"), "cases": len(results), "positions_per_prediction_set": 368,
        "query_case_events_per_stage": sum(row["query_n"] for row in results),
        "clean_endpoints": clean_summary, "injection_kinds": dict(Counter(row["injection_kind"] for row in results)),
        "per_prediction_set": {}, "all_cases": {}, "paired_vs_cache": {},
        "withdrawn_equals_fresh": {arm: sum(row["withdrawn_equals_fresh"][arm] for row in results) for arm in ARMS},
        "restored_equals_clean": {arm: sum(row["restored_equals_clean"][arm] for row in results) for arm in ARMS},
        "residual": {arm: aggregate([row["residual"][arm] for row in results]) for arm in ARMS},
    }
    for stage in STAGES:
        summary["all_cases"][stage] = {arm: aggregate([row["metrics"][stage][arm] for row in results]) for arm in ARMS}
        summary["paired_vs_cache"][stage] = {arm: aggregate([row["paired_vs_cache"][stage][arm] for row in results]) for arm in ARMS}
    for rep in protocol["prediction_sets"]:
        subset = [row for row in results if row["rep"] == rep]
        summary["per_prediction_set"][str(rep)] = {
            stage: {arm: aggregate([row["metrics"][stage][arm] for row in subset]) for arm in ARMS} for stage in STAGES}
    summary["input_source_hashes_preserved"] = all(sha(path) == digest for path, digest in manifest.items())
    summary["frozen_local_files_preserved"] = all(sha(HERE / rel) == digest for rel, digest in protocol["frozen_files"].items())
    summary["semantic_output_digests"] = {
        name: sha(target / name) for name in ("baseline_routes.json", "cases.json", "case_routes.jsonl")}
    write(target / "summary.json", summary)
    write(target / "execution_metadata.json", {"run": run_name, "elapsed_seconds": time.perf_counter() - started,
                                               "completed_utc": datetime.now(timezone.utc).isoformat(),
                                               "runtime_is_not_model_latency": True})
    assert summary["input_source_hashes_preserved"] and summary["frozen_local_files_preserved"]
    assert all(value == 1104 for value in summary["withdrawn_equals_fresh"].values())
    assert all(value == 1104 for value in summary["restored_equals_clean"].values())
    journal("run_complete", run=run_name, cases=len(results), summary_sha256=sha(target / "summary.json"))
    print(json.dumps({"event": "run_complete", "run": run_name,
                      "withdrawn_equals_fresh": summary["withdrawn_equals_fresh"],
                      "restored_equals_clean": summary["restored_equals_clean"],
                      "wrong_approval_r1": summary["per_prediction_set"]["1"]["wrong_approval"]}), flush=True)


def compare_runs():
    first, second = HERE / "runs/first", HERE / "runs/repeat"
    files = ("baseline_routes.json", "cases.json", "case_routes.jsonl", "summary.json")
    equality = {name: sha(first / name) == sha(second / name) for name in files}
    result = {"protocol_sha256": sha(HERE / "protocol.json"), "files_equal": equality,
              "all_equal": all(equality.values()),
              "normalization": "Only actual-rule runtime timestamps were removed before saving semantic outputs; every route, support, label, metric, and rule decision field is compared."}
    write(HERE / "repeat_verification.json", result)
    assert result["all_equal"], result
    write(HERE / "summary.json", read(first / "summary.json"))
    journal("repeat_verified", **result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "run", "compare"))
    parser.add_argument("--run-name", choices=("first", "repeat"), default="first")
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            prepare()
        elif args.command == "run":
            run(args.run_name)
        else:
            compare_runs()
    except Exception as error:
        journal("failure", command=args.command, run=args.run_name,
                type=type(error).__name__, message=str(error))
        raise
