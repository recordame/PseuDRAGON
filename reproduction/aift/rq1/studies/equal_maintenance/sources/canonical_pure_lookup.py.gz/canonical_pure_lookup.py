from typing import Optional, Dict, Any

def get_learned_pii_classification(self, column_name: str, column_comment: str='', data_type: str='') -> Optional[Dict[str, Any]]:
    """Reuse a unanimous exact-name judgment or report conflicting active labels.

        Args:
            column_name: Column name
            column_comment: Column comment/description for similarity search
            data_type: Column data type

        Returns:
            Dict with classification info if learned, None otherwise
            Returns: {"classification": "PII"/"Non-PII", "match_type": "exact",
                      "similar_column": str, "similarity": float, "rationale": str}
        """
    col_key = column_name.lower()
    entries = [entry for entry in self.preferences.get('column_exact', {}).values() if entry.get('column_name', '').lower() == col_key]
    correction = self.preferences.get('pii_classification', {}).get(col_key)
    labels = {entry.get('classification', entry.get('pii_type')) for entry in entries}
    if correction:
        labels.add(correction.get('classification'))
    labels.discard(None)
    if not labels:
        return None
    if not labels.issubset({'PII', 'Non-PII'}) or len(labels) != 1:
        return {'match_type': 'conflict', 'reason': 'Conflicting active approvals'}
    return {'classification': next(iter(labels)), 'match_type': 'exact', 'similar_column': column_name, 'similarity': 1.0, 'rationale': (correction or {}).get('rationale', 'Confirmed expert judgment'), 'change_count': (correction or {}).get('change_count', 0)}
