#!/usr/bin/env python3
"""Freeze and execute nested train-only accumulation with archived model outputs."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import shutil
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / '20260928_latest_source_order_reuse'
CONDITIONS = ('all_selections_history_rules', 'all_selections_name_cache', 'all_selections_name_cache_rules')
SEEDS = tuple(range(20))
PERCENTAGES = (0, 25, 50, 75, 100)
REPETITIONS = (1, 2, 3)


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def journal(event, **data):
    with (HERE / 'journal.jsonl').open('a') as stream:
        stream.write(json.dumps({'utc': datetime.now(timezone.utc).isoformat(), 'event': event, **data}) + '\n')


def prepare():
    if (HERE / 'protocol.json').exists():
        raise RuntimeError('Frozen protocol already exists; preserve it.')
    for relative in ['inputs/records.json', 'inputs/groups.json', 'sources/expert_preference_manager.py', 'sources/heuristic_pattern_learner.py']:
        target = HERE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile((HERE.parents[3] / 'src/pseudragon/rag' / Path(relative).name) if relative.startswith('sources/') else SOURCE / relative, target)
    shutil.copyfile(SOURCE / 'run_replay.py', HERE / 'replay_helpers.py')
    shutil.copyfile(SOURCE / 'results.json', HERE / 'inputs/previous_results.json')
    records = read(HERE / 'inputs/records.json')
    groups = read(HERE / 'inputs/groups.json')['groups']
    assert len(records) == 92 and sum(x['label'] for x in records) == 32
    schedules = {}
    for seed in SEEDS:
        schedules[str(seed)] = {}
        for group, tables in groups.items():
            ids = sorted(x['id'] for x in records if x['table'] not in tables)
            random.Random(f'pseudragon-growth-v1:{seed}:{group}').shuffle(ids)
            schedules[str(seed)][group] = {'acquisition_order': ids, 'prefix_sizes': {str(p): len(ids) * p // 100 for p in PERCENTAGES}}
    write(HERE / 'inputs/schedules.json', schedules)
    frozen = {str(p.relative_to(HERE)): sha(p) for subdir in ('inputs', 'sources') for p in (HERE / subdir).glob('*') if p.is_file()}
    frozen['replay_helpers.py'] = sha(HERE / 'replay_helpers.py')
    write(HERE / 'protocol.json', {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'study': 'Matched accumulation replay after conflict validation for every automatically generated rule',
        'status_at_freeze': 'Original and first repaired accumulation outcomes known. Final accumulation outcomes not yet computed. Same inputs, acquisition orders, archived predictions and0.10 threshold; validate initial candidates, exact fallback generation and both refinement paths against all matching feedback; retain manual rules.',
        'training_order_seeds': list(SEEDS), 'percentages': list(PERCENTAGES), 'repetitions': list(REPETITIONS),
        'conditions': list(CONDITIONS), 'groups': groups,
        'schedule': '20 fixed random acquisition orders per held-out family, independent of labels. Stage p uses floor(p*N/100) of that order. The same nested subsets are used for every model repetition and arm. Stores are reconstructed in sorted table.column order to isolate available-record composition from ingestion order.',
        'training': 'One reference-confirmed selection for each selected training record plus correction history when that repetition\'s frozen fallback differs from the reference. The actual production learner is rebuilt from empty stores at each stage. Reference approvals are simulated, not newly collected practitioner decisions.',
        'routing': 'Production exact correction history then actual learned rules. Controls use unanimous exact-name cache, with or without learned rules. Embeddings and manual/static rules disabled, unchanged from previous replay.',
        'heldout': 'Five existing label-blind schema-family splits. Entire target family excluded from every store. Test labels unavailable to routing; used only by external scoring.',
        'fallback': 'Archived predictions from 20260928_latest_source_order_reuse for gpt-oss-120b, fixed across every accumulation stage and arm; no new model execution.',
        'primary_outcomes': ['memory routes', 'fallback routes', 'wrong memory routes', 'F1', 'changed predictions versus fixed fallback', 'fixed and harmed predictions', 'coverage losses and label reversals between adjacent prefixes'],
        'unit': '92 unique fields scored separately at each order, stage, model repetition, and condition; repeated views are not independent new fields.',
        'endpoint': 'Compare100% with archived full-data metrics for each arm and model repetition (75,75,83 memory routes); retain any differences rather than selecting outcomes.',
        'scope': 'Controlled record accumulation replay, not prospective chronological deployment, independent adjudication, or new institutional data. No monotonicity assumption.',
        'runner_sha256': sha(__file__), 'files': frozen,
    })
    journal('protocol_frozen', protocol_sha256=sha(HERE / 'protocol.json'), partial_prefix_results_computed=False)


def load_helpers():
    spec = importlib.util.spec_from_file_location('growth_replay_helpers', HERE / 'replay_helpers.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE
    return module


def bounds(values):
    return {'mean': statistics.mean(values), 'min': min(values), 'max': max(values)}


def run():
    protocol = read(HERE / 'protocol.json')
    assert sha(__file__) == protocol['runner_sha256']
    assert all(sha(HERE / p) == value for p, value in protocol['files'].items())
    if (HERE / 'results.json').exists():
        raise RuntimeError('Results already exist; preserve evidence.')
    helper = load_helpers()
    records = read(HERE / 'inputs/records.json')
    labels = {x['id']: x['label'] for x in records}
    by_id = {x['id']: x for x in records}
    schedules = read(HERE / 'inputs/schedules.json')
    old = read(HERE / 'inputs/previous_results.json')
    aggregates, transitions, endpoint_checks = [], [], []
    metric_keys = ('reused', 'fallback_routes', 'wrong_reuse', 'fixed', 'harmed', 'F1')
    store_count, route_count = 0, 0
    with (HERE / 'snapshots.jsonl').open('w') as snapshots:
        for seed in SEEDS:
            previous = {}
            for percentage in PERCENTAGES:
                rows_per_rep = defaultdict(list)
                for rep in REPETITIONS:
                    for group, tables in protocol['groups'].items():
                        schedule = schedules[str(seed)][group]
                        n = schedule['prefix_sizes'][str(percentage)]
                        selected = sorted(schedule['acquisition_order'][:n])
                        train = [dict(by_id[key], fallback=by_id[key]['fallbacks'][str(rep)]) for key in selected]
                        queries = [{k: x[k] for k in ('id', 'table', 'column', 'comment')} | {'fallback': x['fallbacks'][str(rep)]} for x in records if x['table'] in tables]
                        assert not set(selected) & {q['id'] for q in queries}
                        assert all(x['table'] not in tables for x in train)
                        folder = HERE / 'stores' / f's{seed:02d}' / f'p{percentage:03d}' / f'r{rep}' / group
                        manager, changes = helper.train_store(train, 'all_selections', folder)
                        store = helper.semantic(read(folder / 'feedback.json'))
                        rules = helper.semantic(read(folder / 'heuristics.json'))
                        names = {x['column'].upper() for x in train}
                        assert all(set(rule.get('sample_columns', [])) <= names for rule in rules['heuristics'])
                        rows = []
                        for query in queries:
                            assert 'label' not in query and 'action' not in query
                            exact = manager.get_learned_pii_classification(query['column'], query['comment'])
                            if exact is not None:
                                assert exact['match_type'] == 'exact'
                                support = [x['id'] for x in train if x['id'] in changes and x['column'].lower() == query['column'].lower()]
                                routed = dict(helper.baseline(query), prediction=exact['classification'] == 'PII', route='history', support_ids=support, reason='exact_correction_history')
                            else:
                                production = manager.classify_by_heuristics(query['column'], query['comment'])
                                routed = helper.rules_route(query, train, rules['heuristics'])
                                assert (production is None) == (routed['route'] == 'fallback')
                                if production is not None:
                                    assert (production['classification'] == 'PII', production['pattern']) == (routed['prediction'], routed['pattern'])
                            rows.append(dict(query, condition=CONDITIONS[0], **routed))
                            for condition, use_rules in ((CONDITIONS[1], False), (CONDITIONS[2], True)):
                                rows.append(dict(query, condition=condition, **helper.cache_route(query, train, rules['heuristics'], use_rules)))
                        for row in rows:
                            assert row['route'] == 'fallback' or row['support_ids']
                            assert set(row['support_ids']) <= set(selected)
                        snapshot = {'seed': seed, 'percentage': percentage, 'repetition': rep, 'group': group, 'training_ids': selected, 'correction_ids': changes, 'store': store, 'rules': rules, 'rows': rows}
                        snapshots.write(json.dumps(snapshot, ensure_ascii=False, separators=(',', ':')) + '\n')
                        rows_per_rep[rep].extend(rows)
                        store_count += 1
                        route_count += len(rows)
                for rep in REPETITIONS:
                    for condition in CONDITIONS:
                        rows = [x for x in rows_per_rep[rep] if x['condition'] == condition]
                        assert len(rows) == len({x['id'] for x in rows}) == 92
                        metrics = helper.metrics(rows, labels)
                        aggregates.append({'seed': seed, 'percentage': percentage, 'repetition': rep, 'condition': condition, **metrics, 'changed_predictions': sum(x['prediction'] != x['fallback'] for x in rows)})
                        key = (rep, condition)
                        current = {x['id']: x for x in rows}
                        if key in previous:
                            prior = previous[key]
                            lost = [k for k in current if prior[k]['route'] != 'fallback' and current[k]['route'] == 'fallback']
                            gained = [k for k in current if prior[k]['route'] == 'fallback' and current[k]['route'] != 'fallback']
                            reversals = [k for k in current if prior[k]['prediction'] != current[k]['prediction']]
                            newly_wrong = [k for k in current if prior[k]['prediction'] == labels[k] != current[k]['prediction']]
                            transitions.append({'seed': seed, 'repetition': rep, 'condition': condition, 'to_percentage': percentage, 'lost_memory_ids': lost, 'gained_memory_ids': gained, 'label_reversal_ids': reversals, 'newly_wrong_ids': newly_wrong, 'net_memory_change': len(gained) - len(lost)})
                        previous[key] = current
                        if percentage == 100:
                            expected = old['per_repeat'][str(rep)][condition]
                            endpoint_checks.append({'seed': seed, 'repetition': rep, 'condition': condition, 'passed': all(metrics[k] == expected[k] for k in metrics), 'differences': {k: {'original': expected[k], 'repaired': metrics[k]} for k in metrics if metrics[k] != expected[k]}})
            print(f'Completed order {seed + 1}/{len(SEEDS)}', flush=True)
    summary = []
    for condition in CONDITIONS:
        for percentage in PERCENTAGES:
            selected = [x for x in aggregates if x['condition'] == condition and x['percentage'] == percentage]
            summary.append({'condition': condition, 'percentage': percentage, 'order_repetition_views': len(selected), 'unique_fields': 92, **{k: bounds([x[k] for x in selected]) for k in metric_keys}})
    monotonicity = []
    for condition in CONDITIONS:
        count_nondecreasing = 0
        count_nested = 0
        bad_sequences = []
        for seed in SEEDS:
            for rep in REPETITIONS:
                selected = [x for x in transitions if x['condition'] == condition and x['seed'] == seed and x['repetition'] == rep]
                count_nondecreasing += all(x['net_memory_change'] >= 0 for x in selected)
                count_nested += all(not x['lost_memory_ids'] for x in selected)
                if any(x['lost_memory_ids'] or x['label_reversal_ids'] for x in selected):
                    bad_sequences.append({'seed': seed, 'repetition': rep})
        selected = [x for x in transitions if x['condition'] == condition]
        monotonicity.append({'condition': condition, 'order_repetition_sequences': len(SEEDS) * len(REPETITIONS), 'nondecreasing_coverage_sequences': count_nondecreasing, 'strictly_nested_memory_sequences': count_nested, 'transitions_with_memory_loss': sum(bool(x['lost_memory_ids']) for x in selected), 'transitions_with_label_reversals': sum(bool(x['label_reversal_ids']) for x in selected), 'bad_sequences': bad_sequences, 'first_memory_loss': next((x for x in selected if x['lost_memory_ids']), None), 'first_label_reversal': next((x for x in selected if x['label_reversal_ids']), None)})
    write(HERE / 'results.json', {'protocol_sha256': sha(HERE / 'protocol.json'), 'summary': summary, 'monotonicity': monotonicity, 'metrics': aggregates, 'transitions': transitions, 'endpoint_checks': endpoint_checks, 'store_snapshots': store_count, 'routing_records': route_count, 'unique_fields': 92, 'new_model_calls': 0, 'new_practitioner_decisions': 0})
    assert all(sha(HERE / p) == value for p, value in protocol['files'].items())
    journal('replay_complete', result_sha256=sha(HERE / 'results.json'), stores=store_count, routing_records=route_count, endpoints=len(endpoint_checks))
    print(json.dumps({'summary': summary, 'monotonicity': monotonicity}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare', 'run'))
    args = parser.parse_args()
    prepare() if args.command == 'prepare' else run()
