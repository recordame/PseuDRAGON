#!/usr/bin/env python3
"""Reconstruct accumulation routing and scores using the standard library only."""
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decide(row, train, store, rules):
    fallback = (row['fallback'], 'fallback', None, [])
    key = row['column'].lower()
    condition = row['condition']
    if 'name_cache' in condition:
        exact = [x for x in train if x['column'].lower() == key]
        if exact:
            labels = {x['label'] for x in exact}
            if len(labels) != 1:
                return fallback
            return labels.pop(), 'name_cache', None, [x['id'] for x in exact]
        if not condition.endswith('_rules'):
            return fallback
    elif key in store['pii_classification']:
        label = store['pii_classification'][key]['classification'] == 'PII'
        support = [x['id'] for x in train if x['column'].lower() == key and x['fallback'] != x['label']]
        return label, 'history', None, support
    for rule in sorted([x for x in rules['heuristics'] if x.get('enabled', True)], key=lambda x: x.get('priority', 0), reverse=True):
        if re.search(rule['regex'], row['column'].upper(), re.IGNORECASE):
            support = [x['id'] for x in train if x['column'].upper() in rule.get('sample_columns', [])]
            return rule.get('pii_type', 'PII') == 'PII', 'rule', rule['regex'], support
    return fallback


def score(rows, labels):
    c = Counter()
    for row in rows:
        label, pred, fallback = labels[row['id']], row['prediction'], row['fallback']
        c['TP' if label and pred else 'FP' if pred else 'FN' if label else 'TN'] += 1
        c['reused'] += row['route'] != 'fallback'
        c['wrong_reuse'] += row['route'] != 'fallback' and label != pred
        c['fixed'] += label != fallback and label == pred
        c['harmed'] += label == fallback and label != pred
        c['changed_predictions'] += pred != fallback
        c[row['route'] + '_routes'] += 1
    tp, fp, fn = (c[x] for x in ('TP', 'FP', 'FN'))
    return {k: c[k] for k in ('TP', 'FP', 'FN', 'TN', 'reused', 'wrong_reuse', 'fixed', 'harmed', 'changed_predictions', 'history_routes', 'rule_routes', 'name_cache_routes', 'fallback_routes')} | {
        'n': len(rows), 'precision': tp / (tp + fp) if tp + fp else 0.,
        'recall': tp / (tp + fn) if tp + fn else 0.,
        'F1': 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.,
        'avoided_fresh_classification_requests': c['reused'], 'remaining_fresh_classification_requests': c['fallback_routes'],
        'reuse_coverage': c['reused'] / len(rows),
    }


def main():
    protocol = read(HERE / 'protocol.json')
    assert digest(HERE / 'run_growth.py') == protocol['runner_sha256']
    assert all(digest(HERE / key) == value for key, value in protocol['files'].items())
    records = read(HERE / 'inputs/records.json')
    by_id = {x['id']: x for x in records}
    labels = {x['id']: x['label'] for x in records}
    assert len(by_id) == 92 and sum(labels.values()) == 32
    schedules = read(HERE / 'inputs/schedules.json')
    results = read(HERE / 'results.json')
    reported = {(x['seed'], x['percentage'], x['repetition'], x['condition']): x for x in results['metrics']}
    assert len(reported) == 20 * 5 * 3 * 3
    collected = defaultdict(list)
    checked_routes, checked_stores = 0, 0
    for line in (HERE / 'snapshots.jsonl').open():
        snap = json.loads(line)
        seed, percentage, rep, group = (snap[x] for x in ('seed', 'percentage', 'repetition', 'group'))
        tables = protocol['groups'][group]
        schedule = schedules[str(seed)][group]
        allowed = [x for x in records if x['table'] not in tables]
        assert sorted(schedule['acquisition_order']) == sorted(x['id'] for x in allowed)
        n = len(allowed) * percentage // 100
        assert n == schedule['prefix_sizes'][str(percentage)]
        selected = sorted(schedule['acquisition_order'][:n])
        assert selected == snap['training_ids']
        train = [dict(by_id[key], fallback=by_id[key]['fallbacks'][str(rep)]) for key in selected]
        corrections = [x['id'] for x in train if x['fallback'] != x['label']]
        assert corrections == snap['correction_ids']
        assert snap['store']['statistics']['total_selections'] == len(train) + len(corrections)
        assert set(snap['store']['pii_classification']) == {by_id[key]['column'].lower() for key in corrections}
        assert all(set(rule.get('sample_columns', [])) <= {x['column'].upper() for x in train} for rule in snap['rules']['heuristics'])
        for row in snap['rows']:
            assert row['table'] in tables and row['id'] not in selected
            assert row['fallback'] is by_id[row['id']]['fallbacks'][str(rep)]
            assert decide(row, train, snap['store'], snap['rules']) == (row['prediction'], row['route'], row['pattern'], row['support_ids'])
            assert set(row['support_ids']) <= set(selected)
            assert row['route'] == 'fallback' or row['support_ids']
            collected[seed, percentage, rep, row['condition']].append(row)
            checked_routes += 1
        checked_stores += 1
    assert checked_stores == results['store_snapshots'] == 1500
    assert checked_routes == results['routing_records'] == 82800
    for key, rows in collected.items():
        assert len(rows) == len({x['id'] for x in rows}) == 92
        recounted = score(rows, labels)
        assert all(reported[key][name] == value for name, value in recounted.items())
    summary_checks = 0
    for summary in results['summary']:
        rows = [x for x in reported.values() if x['percentage'] == summary['percentage'] and x['condition'] == summary['condition']]
        assert len(rows) == 60
        for metric in ('reused', 'fallback_routes', 'wrong_reuse', 'fixed', 'harmed', 'F1'):
            values = [x[metric] for x in rows]
            assert summary[metric] == {'mean': statistics.mean(values), 'min': min(values), 'max': max(values)}
        summary_checks += 1
    transition_checks = 0
    for transition in results['transitions']:
        seed, percentage, rep, condition = (transition[x] for x in ('seed', 'to_percentage', 'repetition', 'condition'))
        current = {x['id']: x for x in collected[seed, percentage, rep, condition]}
        previous = {x['id']: x for x in collected[seed, percentage - 25, rep, condition]}
        lost = [k for k in current if previous[k]['route'] != 'fallback' and current[k]['route'] == 'fallback']
        gained = [k for k in current if previous[k]['route'] == 'fallback' and current[k]['route'] != 'fallback']
        reversals = [k for k in current if previous[k]['prediction'] != current[k]['prediction']]
        wrong = [k for k in current if previous[k]['prediction'] == labels[k] != current[k]['prediction']]
        assert (lost, gained, reversals, wrong, len(gained) - len(lost)) == tuple(transition[x] for x in ('lost_memory_ids', 'gained_memory_ids', 'label_reversal_ids', 'newly_wrong_ids', 'net_memory_change'))
        transition_checks += 1
    endpoint_checks = 0
    old = read(HERE / 'inputs/previous_results.json')
    for endpoint in results['endpoint_checks']:
        key = endpoint['seed'], 100, endpoint['repetition'], endpoint['condition']
        expected = old['per_repeat'][str(endpoint['repetition'])][endpoint['condition']]
        assert all(reported[key][metric] == expected[metric] for metric in ('TP', 'FP', 'FN', 'TN', 'F1', 'reused', 'wrong_reuse', 'fixed', 'harmed', 'fallback_routes'))
        endpoint_checks += 1
    report = {'status': 'PASS', 'unique_fields': 92, 'production_code_imported_by_verifier': False, 'new_model_calls': 0, 'store_snapshots': checked_stores, 'independently_reconstructed_routes': checked_routes, 'metric_groups': len(collected), 'summary_groups': summary_checks, 'adjacent_transitions': transition_checks, 'full_data_endpoint_checks': endpoint_checks, 'protocol_sha256': digest(HERE / 'protocol.json'), 'results_sha256': digest(HERE / 'results.json'), 'snapshots_sha256': digest(HERE / 'snapshots.jsonl'), 'verifier_sha256': digest(__file__)}
    (HERE / 'independent_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
