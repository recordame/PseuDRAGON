"""Reconstruct routes and metrics without importing the learner or runner."""
import json
import re
import hashlib
import statistics
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent

def read(p):
    return json.loads(Path(p).read_text())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def score(rows, labels):
    c = Counter()
    for r in rows:
        y, p, f = labels[r['id']], r['prediction'], r['fallback']
        c['TP' if y and p else 'FP' if p else 'FN' if y else 'TN'] += 1
        stored = r['route'] != 'fallback'
        c['reused'] += stored
        c['wrong_reuse'] += stored and p != y
        c['harmed'] += f == y and p != y
        c['fixed'] += f != y and p == y
        c['unseen_queries'] += r['unseen']
        c['unseen_reused'] += r['unseen'] and stored
        c['unseen_wrong'] += r['unseen'] and stored and p != y
        c[r['route'] + '_routes'] += 1
    tp, fp, fn = c['TP'], c['FP'], c['FN']
    return {k: c[k] for k in ['TP', 'FP', 'FN', 'TN', 'reused', 'wrong_reuse', 'harmed', 'fixed', 'unseen_queries', 'unseen_reused', 'unseen_wrong', 'history_routes', 'rule_routes', 'name_cache_routes', 'fallback_routes']} | {'F1': 2*tp/(2*tp+fp+fn)}

def main():
    protocol = read(HERE / 'protocol.json')
    assert sha(HERE / 'run_sensitivity.py') == protocol['runner_sha256']
    assert all(sha(HERE / p) == v for p, v in protocol['files'].items())
    recs = read(HERE / 'inputs/records.json')
    by_id = {r['id']: r for r in recs}
    labels = {r['id']: r['label'] for r in recs}
    schedules = read(HERE / 'inputs/schedules.json')
    configs = {c['id']: c for c in protocol['configs']}
    results = read(HERE / 'results.json')
    reported = {(r['config'], r['percentage'], r['seed'], r['repetition'], r['condition']): r for r in results['metrics']}
    groups = defaultdict(list)
    snapshots = routes = bounds_checked = 0
    candidate_totals = Counter()
    for line in (HERE / 'snapshots.jsonl').open():
        s = json.loads(line)
        cfg = configs[s['config']]
        assert s['applied_parameters'] == [cfg['support'], cfg['score'], cfg['conflict']]
        rep = s['repetition']
        allowed = protocol['groups'][s['group']]
        schedule = schedules[str(s['seed'])][s['group']]
        expected_train = sorted(schedule['acquisition_order'][:schedule['prefix_sizes'][str(s['percentage'])]])
        assert s['training_ids'] == expected_train
        train = [dict(by_id[k], fallback=by_id[k]['fallbacks'][str(rep)]) for k in expected_train]
        assert all(r['table'] not in allowed for r in train)
        names = {r['column'].upper() for r in train}
        corrections = [r['id'] for r in train if r['label'] != r['fallback']]
        assert corrections == s['correction_ids']
        assert s['store']['statistics']['total_selections'] == len(train) + len(corrections)
        feedback = [(v['column_name'], v['pii_type'] == 'PII') for v in s['store']['column_exact'].values()]
        feedback += [(k, v['classification'] == 'PII') for k, v in s['store']['pii_classification'].items()]
        for rule in s['rules']['heuristics']:
            support = [y for n, y in feedback if re.search(rule['regex'], n, re.I)]
            assert support
            conflict = sum(y != (rule['pii_type'] == 'PII') for y in support) / len(support)
            assert conflict <= cfg['conflict'] + 1e-12
            bounds_checked += 1
        for c in s['initial_candidate_counts']:
            candidate_totals[s['config'],s['percentage']] += sum(c['counts'].values())
        assert s['rule_types'] == dict(Counter(x.get('pattern_type') for x in s['rules']['heuristics']))
        for r in s['rows']:
            assert r['table'] in allowed and r['id'] not in expected_train
            assert r['fallback'] == by_id[r['id']]['fallbacks'][str(rep)]
            assert r['unseen'] == (r['column'].upper() not in names)
            expected = (r['fallback'], 'fallback', None, [])
            key = r['column'].lower()
            exact = [x for x in train if x['column'].lower() == key]
            use_rules = True
            if 'name_cache' in r['condition']:
                if exact:
                    use_rules = False
                    ys = {x['label'] for x in exact}
                    if len(ys) == 1:
                        expected = (next(iter(ys)), 'name_cache', None, [x['id'] for x in exact])
                elif not r['condition'].endswith('_rules'):
                    use_rules = False
            elif key in s['store']['pii_classification']:
                use_rules = False
                expected = (s['store']['pii_classification'][key]['classification'] == 'PII', 'history', None, [x['id'] for x in exact if x['id'] in corrections])
            if use_rules:
                rules = sorted([x for x in s['rules']['heuristics'] if x.get('enabled',True)], key=lambda x: x.get('priority',0), reverse=True)
                for rule in rules:
                    if re.search(rule['regex'],r['column'],re.I):
                        expected = (rule['pii_type'] == 'PII','rule',rule['regex'],[x['id'] for x in train if x['column'].upper() in rule.get('sample_columns',[])])
                        break
            assert expected == tuple(r[k] for k in ['prediction','route','pattern','support_ids'])
            assert set(r['support_ids']) <= set(expected_train)
            groups[s['config'],s['percentage'],s['seed'],rep,r['condition']].append(r)
            routes += 1
        snapshots += 1
    assert snapshots == results['stores'] == 9*21*3*5
    assert len(groups) == len(reported) == 9*21*3*3
    for k, rows in groups.items():
        assert len(rows) == len({r['id'] for r in rows}) == 92
        assert all(reported[k][n] == v for n,v in score(rows,labels).items())
    for s in results['summary']:
        rows=[r for r in reported.values() if (r['config'],r['percentage'],r['condition'])==(s['config']['id'],s['percentage'],s['condition'])]
        assert len(rows)==s['views']==(60 if s['percentage']==25 else 3)
        for name in ['reused','wrong_reuse','harmed','F1','unseen_queries','unseen_reused','unseen_wrong']:
            vals=[r[name] for r in rows]
            assert s[name]=={'mean':statistics.mean(vals),'min':min(vals),'max':max(vals)}
    assert all(sha(HERE / p) == v for p,v in protocol['files'].items())
    report={'status':'PASS','independent_of_runner_and_production_imports':True,'unique_fields':92,'store_snapshots':snapshots,'reconstructed_routes':routes,'metric_groups':len(groups),'rule_conflict_bound_checks':bounds_checked,'summary_groups':len(results['summary']),'candidate_counts': [{'config':k[0],'percentage':k[1],'candidates':v} for k,v in sorted(candidate_totals.items())],'protocol_sha256':sha(HERE/'protocol.json'),'results_sha256':sha(HERE/'results.json'),'verifier_sha256':sha(__file__)}
    (HERE/'independent_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='candidate_counts'},indent=2))

if __name__=='__main__':
    main()
