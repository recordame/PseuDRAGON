"""Frozen parameter comparison over recorded predictions; no model calls."""
import importlib.util
import itertools
import json
import hashlib
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import shutil
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / '20260929_reuse_growth_repaired_v2'
ARMS = ['all_selections_history_rules', 'all_selections_name_cache', 'all_selections_name_cache_rules']
CONFIGS = [{'id': 'default', 'support': 2, 'score': .8, 'conflict': .1}] + [
    {'id': f's{m}-q{q}-c{c}', 'support': m, 'score': q, 'conflict': c}
    for m, q, c in itertools.product((2, 3), (.7, .9), (0., .2))
]

def read(p):
    return json.loads(Path(p).read_text())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def prepare():
    assert not (HERE / 'protocol.json').exists()
    for rel in ['inputs/records.json', 'inputs/groups.json', 'inputs/schedules.json',
                'sources/expert_preference_manager.py', 'sources/heuristic_pattern_learner.py',
                'replay_helpers.py']:
        shutil.copyfile(PRIOR / rel, HERE / rel)
    shutil.copyfile(PRIOR / 'results.json', HERE / 'inputs/default_growth.json')
    frozen = {str(p.relative_to(HERE)): sha(p) for d in ['inputs', 'sources'] for p in (HERE / d).iterdir()}
    frozen['replay_helpers.py'] = sha(HERE / 'replay_helpers.py')
    write(HERE / 'protocol.json', {
        'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'status_before_run': 'Published default results known. These alternate parameter outcomes not yet computed.',
        'base_commit': 'd5cc1135', 'configs': CONFIGS, 'arms': ARMS,
        'groups': read(HERE / 'inputs/groups.json')['groups'],
        'design': 'Eight predeclared two-level factorial corners plus the unchanged default. No selection of a winning default or held-out tuning.',
        'stages': {'25': list(range(20)), '100': [0]},
        'repetitions': [1, 2, 3],
        'data': 'Same92 unique fields,32positive60negative, five label-blind family folds. Entire query family excluded; reference used only for training approvals and separate scoring.',
        'acquisition': 'Existing frozen nested orders. At25% use floor(N/4); at100% use all training fields once per prediction set, avoiding duplicate full-store orders. Canonical ingestion order.',
        'fallbacks': 'Same three archived gpt-oss-120b prediction sets, fixed across configurations and arms. No inference or human annotation.',
        'parameter_scope': 'Instance attributes changed before any feedback ingestion. Candidate-score threshold applies to initial extraction and longer-suffix refinement; exact-to-suffix merging uses support and its existing0.7+0.1*count priority. No claim of uniform global confidence threshold.',
        'outcomes': ['reused', 'wrong_reuse', 'harmed', 'F1', 'unseen_queries', 'unseen_reused', 'unseen_wrong', 'final_rule_types', 'initial_candidate_counts'],
        'units': 'Aggregate92fields for each order and prediction set. Repeated views of same corpus, not independent datasets. Compare stages separately.',
        'checks': ['Default matches frozen prior metrics', 'query family exclusion', 'independent route and arithmetic reconstruction', 'source and input hash preservation'],
        'files': frozen, 'runner_sha256': sha(__file__)
    })

def bounds(vals):
    return {'mean': statistics.mean(vals), 'min': min(vals), 'max': max(vals)}

def run():
    protocol = read(HERE / 'protocol.json')
    assert sha(__file__) == protocol['runner_sha256']
    assert all(sha(HERE / k) == v for k, v in protocol['files'].items())
    assert not (HERE / 'results.json').exists()
    spec = importlib.util.spec_from_file_location('sensitivity_helpers', HERE / 'replay_helpers.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.HERE = HERE
    original_factory = helper.new_manager
    records = read(HERE / 'inputs/records.json')
    by_id = {x['id']: x for x in records}
    labels = {x['id']: x['label'] for x in records}
    schedules = read(HERE / 'inputs/schedules.json')
    prior = read(HERE / 'inputs/default_growth.json')
    metrics, default_checks = [], []
    count = 0
    with (HERE / 'snapshots.jsonl').open('w') as stream:
        for cfg in CONFIGS:
            def factory(folder):
                manager = original_factory(folder)
                learner = manager._heuristic_learner
                learner.MIN_PATTERN_OCCURRENCES = cfg['support']
                learner.MIN_CONFIDENCE = cfg['score']
                learner.MAX_CONFLICT_RATE = cfg['conflict']
                manager.sensitivity_candidates = []
                original_extract = learner._extract_patterns
                def extract(columns, classification):
                    result = original_extract(columns, classification)
                    manager.sensitivity_candidates.append({'label': classification, 'entries': len(columns), 'counts': {k: len(v) for k, v in result.items()}})
                    return result
                learner._extract_patterns = extract
                return manager
            helper.new_manager = factory
            for pct, seeds in protocol['stages'].items():
                pct = int(pct)
                for seed in seeds:
                    for rep in protocol['repetitions']:
                        collected = []
                        for group, tables in protocol['groups'].items():
                            schedule = schedules[str(seed)][group]
                            selected = sorted(schedule['acquisition_order'][:schedule['prefix_sizes'][str(pct)]])
                            train = [dict(by_id[k], fallback=by_id[k]['fallbacks'][str(rep)]) for k in selected]
                            queries = [{k: x[k] for k in ['id', 'table', 'column', 'comment']} | {'fallback': x['fallbacks'][str(rep)]} for x in records if x['table'] in tables]
                            assert not set(selected) & {q['id'] for q in queries}
                            folder = HERE / 'stores' / cfg['id'] / f'p{pct}-s{seed}-r{rep}' / group
                            manager, changes = helper.train_store(train, 'all_selections', folder)
                            learner = manager._heuristic_learner
                            actual = [learner.MIN_PATTERN_OCCURRENCES, learner.MIN_CONFIDENCE, learner.MAX_CONFLICT_RATE]
                            assert actual == [cfg['support'], cfg['score'], cfg['conflict']]
                            store = helper.semantic(read(folder / 'feedback.json'))
                            rules = helper.semantic(read(folder / 'heuristics.json'))
                            names = {x['column'].upper() for x in train}
                            rows = []
                            for q in queries:
                                result = manager.get_learned_pii_classification(q['column'], q['comment'])
                                if result is not None:
                                    assert result['match_type'] == 'exact'
                                    support = [x['id'] for x in train if x['id'] in changes and x['column'].lower() == q['column'].lower()]
                                    route = dict(helper.baseline(q), prediction=result['classification'] == 'PII', route='history', support_ids=support, reason='exact_correction_history')
                                else:
                                    route = helper.rules_route(q, train, rules['heuristics'])
                                    prod = manager.classify_by_heuristics(q['column'], q['comment'])
                                    assert (prod is None) == (route['route'] == 'fallback')
                                    if prod is not None:
                                        assert (prod['classification'] == 'PII', prod['pattern']) == (route['prediction'], route['pattern'])
                                rows.append(dict(q, condition=ARMS[0], unseen=q['column'].upper() not in names, **route))
                                for arm, use_rules in [(ARMS[1], False), (ARMS[2], True)]:
                                    rows.append(dict(q, condition=arm, unseen=q['column'].upper() not in names, **helper.cache_route(q, train, rules['heuristics'], use_rules)))
                            for row in rows:
                                assert set(row['support_ids']) <= set(selected)
                                assert row['route'] == 'fallback' or row['support_ids']
                            snap = {'config': cfg['id'], 'applied_parameters': actual, 'percentage': pct, 'seed': seed, 'repetition': rep, 'group': group, 'training_ids': selected, 'correction_ids': changes, 'store': store, 'rules': rules, 'initial_candidate_counts': manager.sensitivity_candidates, 'rule_types': dict(Counter(x.get('pattern_type') for x in rules['heuristics'])), 'rows': rows}
                            stream.write(json.dumps(snap, ensure_ascii=False, separators=(',', ':')) + '\n')
                            count += 1
                            collected.extend(rows)
                        for arm in ARMS:
                            rows = [x for x in collected if x['condition'] == arm]
                            assert len(rows) == len({x['id'] for x in rows}) == 92
                            m = helper.metrics(rows, labels)
                            m.update(unseen_queries=sum(x['unseen'] for x in rows), unseen_reused=sum(x['unseen'] and x['route'] != 'fallback' for x in rows), unseen_wrong=sum(x['unseen'] and x['route'] != 'fallback' and x['prediction'] != labels[x['id']] for x in rows))
                            metrics.append({'config': cfg['id'], 'percentage': pct, 'seed': seed, 'repetition': rep, 'condition': arm, **m})
                            if cfg['id'] == 'default':
                                old = next(x for x in prior['metrics'] if (x['seed'], x['percentage'], x['repetition'], x['condition']) == (seed, pct, rep, arm))
                                assert all(m[k] == old[k] for k in ['reused', 'wrong_reuse', 'harmed', 'F1', 'TP', 'FP', 'FN', 'TN'])
                                default_checks.append([seed, pct, rep, arm])
            print('Completed', cfg['id'], flush=True)
    keys = ['reused', 'wrong_reuse', 'harmed', 'F1', 'unseen_queries', 'unseen_reused', 'unseen_wrong']
    summary = []
    for cfg in CONFIGS:
        for pct in (25, 100):
            for arm in ARMS:
                ms = [x for x in metrics if (x['config'], x['percentage'], x['condition']) == (cfg['id'], pct, arm)]
                summary.append({'config': cfg, 'percentage': pct, 'condition': arm, 'views': len(ms), **{k: bounds([x[k] for x in ms]) for k in keys}})
    assert all(sha(HERE / k) == v for k, v in protocol['files'].items())
    write(HERE / 'results.json', {'protocol_sha256': sha(HERE / 'protocol.json'), 'unique_fields': 92, 'stores': count, 'metrics': metrics, 'summary': summary, 'default_checks': len(default_checks), 'new_model_calls': 0})
    print(json.dumps({'stores': count, 'metric_groups': len(metrics), 'default_checks': len(default_checks)}))

if __name__ == '__main__':
    prepare() if sys.argv[1] == 'prepare' else run()
