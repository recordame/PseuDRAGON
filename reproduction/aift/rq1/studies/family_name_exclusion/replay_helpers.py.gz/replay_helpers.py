#!/usr/bin/env python3
"""Replay fresh train-only stores against three frozen source-ordered runs."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import logging
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
logging.disable(logging.CRITICAL)
HERE = Path(__file__).resolve().parent
CONDITIONS = (
    "no_memory", "corrections_history_rules", "all_selections_history_rules",
    "all_selections_name_cache", "all_selections_name_cache_rules",
)
SEEDS = ("corrections_only", "all_selections")


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def semantic(data):
    if isinstance(data, dict):
        return {k: semantic(v) for k, v in data.items() if k not in {
            "timestamp", "created_at", "updated_at", "last_updated", "last_auto_learn"}}
    if isinstance(data, list):
        return [semantic(x) for x in data]
    return data


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def journal(event, **data):
    with (HERE / "journal.jsonl").open("a") as stream:
        stream.write(json.dumps({"utc": datetime.now(timezone.utc).isoformat(),
                                 "event": event, **data}) + "\n")


def prepare(root):
    if (HERE / "protocol.json").exists():
        raise RuntimeError("A frozen protocol already exists.")
    latest = root / "paper/experiments/rq2/20260925_source_order_integrated"
    old = root / "paper/experiments/rq1/20260919_heldout_correction_replay"
    reference_path = root / "paper/experiments/rq1/20260710_cold-start-workflow/operational_reference.json"
    reference = read(reference_path)
    inputs = read(latest / "inputs.json")
    labels = read(latest / "labels.json")
    analysis = read(latest / "analysis.json")
    checked = {(x["repetition"], x["item_id"]): x for x in analysis["rows"] if x["stage"] == 1}
    records, provenance = [], {}
    for item in sorted(inputs, key=lambda x: x["table"] + "." + x["column"]):
        key = item["table"] + "." + item["column"]
        label = reference["oracle_pii_data"][item["table"]][item["column"]]["is_pii"]
        assert label is labels[item["id"]]
        policy = reference["oracle_policy_data"][item["table"]][item["column"]]
        row = {"id": key, "item_id": item["id"], "table": item["table"],
               "column": item["column"], "comment": item["target_metadata"]["comment"],
               "label": label, "action": policy.get("action") or policy["recommended_methods"][0]["method"],
               "fallbacks": {}}
        for rep in (1, 2, 3):
            path = latest / "responses" / f"r{rep}-s1-{item['id']}.json"
            response = read(path)
            assert response["status"] == "complete"
            assert hashlib.sha256(response["raw_response_text"].encode()).hexdigest() == response["raw_sha256"]
            assert json.loads(response["raw_response_text"]) == response["response"]
            parsed = json.loads(response["response"]["message"]["content"])
            assert parsed == response["parsed"]
            prediction = parsed["is_pii"]
            assert type(prediction) is bool
            check = checked[rep, item["id"]]
            assert check["valid"] and check["prediction"] is prediction and check["gold"] is label
            row["fallbacks"][str(rep)] = prediction
            provenance[str(path.relative_to(root))] = sha(path)
        records.append(row)
    assert len(records) == 92 and sum(x["label"] for x in records) == 32
    groups = read(old / "groups.json")
    write(HERE / "inputs/records.json", records)
    write(HERE / "inputs/groups.json", groups)
    for name in ("expert_preference_manager.py", "heuristic_pattern_learner.py"):
        path = root / "src/pseudragon/rag" / name
        target = HERE / "sources" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        provenance[str(path.relative_to(root))] = sha(path)
    for path in (reference_path, latest / "analysis.json", latest / "inputs.json",
                 latest / "labels.json", old / "groups.json"):
        provenance[str(path.relative_to(root))] = sha(path)
    write(HERE / "source_provenance.json", provenance)
    frozen = {str(p.relative_to(HERE)): sha(p) for directory in ("inputs", "sources")
              for p in (HERE / directory).glob("*") if p.is_file()}
    write(HERE / "protocol.json", {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "study": "latest source-ordered frozen-output train-only schema-family reuse replay",
        "outcome_status_at_freeze": "Earlier baseline and old replay known; these matched latest-output reuse results not yet calculated.",
        "conditions": CONDITIONS, "repetitions": [1, 2, 3], "groups": groups["groups"],
        "split": "Same five label-blind table-family components as the prior replay; entire family excluded from training.",
        "training": "Fresh empty correction and rule stores for each repetition, fold and seed. Correction = training reference differs from that repetition's frozen source-ordered prediction. All-selections adds one reference-confirmed selection per training record. These are simulated author-reference approvals.",
        "training_order": "Sorted table.column; record classification change when needed, then selection; trigger production pattern learning once at batch end.",
        "routing": "Production exact correction lookup then learned rules; embedding and static/manual rules disabled. Separate exact-name-cache control uses unanimous training labels and blocks rules on an exact-name conflict.",
        "fallback": "Same repetition's archived source-ordered prediction, shared by all arms; no fresh model execution.",
        "scope": "Column-classification routing only. Count an avoided fresh classification request for each memory route; remaining fallback routes would need inference in an online replay. These are routing counts, not observed latency, token or monetary savings and not policy/gate-call counts.",
        "tests": ["independent rule routing and score reconstruction", "held-out-label flip/permutation invariance", "fresh stores", "train-only support", "input preservation", "conflicting-name abstention"],
        "runner_sha256": sha(__file__), "files": frozen,
    })
    journal("protocol_frozen", protocol_sha256=sha(HERE / "protocol.json"),
            source_classifications_verified=276)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def new_manager(folder):
    m = module("isolated_preference_manager", HERE / "sources/expert_preference_manager.py")
    h = module("isolated_pattern_learner", HERE / "sources/heuristic_pattern_learner.py")
    folder.mkdir(parents=True, exist_ok=True)
    manager = m.ExpertPreferenceManager.__new__(m.ExpertPreferenceManager)
    manager.preference_file = str(folder / "feedback.json")
    manager.preferences = {"version": "1.0", "column_patterns": {}, "column_exact": {},
                           "pii_classification": {}, "statistics": {"total_selections": 0, "last_updated": None}}
    manager.rag_system = None
    manager._column_embeddings = {}
    manager._embedding_generator = None
    manager._heuristic_learner = h.HeuristicPatternLearner(manager.preference_file, str(folder / "heuristics.json"))
    assert manager._heuristic_learner.MAX_CONFLICT_RATE == 0.10
    manager._save_preferences()
    manager._heuristic_learner._save_heuristics(manager._heuristic_learner._create_empty_heuristics())
    return manager


def classification(label):
    return "PII" if label else "Non-PII"


def train_store(train, seed, folder):
    manager = new_manager(folder)
    changes = []
    for row in train:
        if row["fallback"] != row["label"]:
            manager.record_pii_classification_change(row["column"], classification(row["fallback"]),
                classification(row["label"]), rationale="Training author-reference replay: " + row["id"],
                column_comment=row["comment"])
            changes.append(row["id"])
        if seed == "all_selections":
            manager.record_selection(row["table"], row["column"], classification(row["label"]),
                                     row["action"], [row["action"]], 0, column_comment=row["comment"])
    assert manager.trigger_pattern_learning() is not None
    return manager, changes


def baseline(query):
    return {"prediction": query["fallback"], "route": "fallback", "pattern": None,
            "support_ids": [], "reason": "no_reuse"}


def rules_route(query, train, rules):
    for rule in sorted((x for x in rules if x.get("enabled", True)),
                       key=lambda x: x.get("priority", 0), reverse=True):
        if re.search(rule["regex"], query["column"].upper(), re.IGNORECASE):
            support = [x["id"] for x in train if x["column"].upper() in rule.get("sample_columns", [])]
            assert support
            return dict(baseline(query), prediction=rule.get("pii_type", "PII") == "PII", route="rule",
                        pattern=rule["regex"], support_ids=support, reason="trained_rule")
    return baseline(query)


def cache_route(query, train, rules, use_rules):
    support = [x for x in train if x["column"].lower() == query["column"].lower()]
    if support:
        values = {x["label"] for x in support}
        if len(values) != 1:
            return dict(baseline(query), reason="conflicting_exact_labels")
        return dict(baseline(query), prediction=next(iter(values)), route="name_cache",
                    support_ids=[x["id"] for x in support], reason="unanimous_exact_name")
    return rules_route(query, train, rules) if use_rules else baseline(query)


def fold(records, rep, tables, seed, folder):
    train = [dict(x, fallback=x["fallbacks"][str(rep)]) for x in records if x["table"] not in tables]
    queries = [{k: x[k] for k in ("id", "table", "column", "comment")} |
               {"fallback": x["fallbacks"][str(rep)]} for x in records if x["table"] in tables]
    manager, changes = train_store(train, seed, folder)
    store, rules = read(folder / "feedback.json"), read(folder / "heuristics.json")
    names = {x["column"].upper() for x in train}
    assert all(set(x.get("sample_columns", [])) <= names for x in rules["heuristics"])
    rows = []
    for query in queries:
        assert "label" not in query and "action" not in query
        result = manager.get_learned_pii_classification(query["column"], query["comment"])
        independent = rules_route(query, train, rules["heuristics"])
        if result is not None:
            assert result["match_type"] == "exact"
            support = [x["id"] for x in train if x["id"] in changes and x["column"].lower() == query["column"].lower()]
            route = dict(baseline(query), prediction=result["classification"] == "PII", route="history",
                         support_ids=support, reason="exact_correction_history")
            assert route["prediction"] == (store["pii_classification"][query["column"].lower()]["classification"] == "PII")
        else:
            result = manager.classify_by_heuristics(query["column"], query["comment"])
            route = independent
            assert (result is None) == (route["route"] == "fallback")
            if result is not None:
                assert (result["classification"] == "PII", result["pattern"]) == (route["prediction"], route["pattern"])
        condition = "corrections_history_rules" if seed == "corrections_only" else "all_selections_history_rules"
        rows.append(dict(query, condition=condition, **route))
        if seed == "all_selections":
            rows.append(dict(query, condition="no_memory", **baseline(query)))
            for condition, use_rules in (("all_selections_name_cache", False), ("all_selections_name_cache_rules", True)):
                rows.append(dict(query, condition=condition, **cache_route(query, train, rules["heuristics"], use_rules)))
    for row in rows:
        assert row["route"] == "fallback" or row["support_ids"]
        assert all(x.split(".", 1)[0] not in tables for x in row["support_ids"])
    return {"train_ids": [x["id"] for x in train], "query_ids": [x["id"] for x in queries],
            "correction_ids": changes, "store": semantic(store), "rules": semantic(rules), "routes": rows}


def metrics(rows, labels):
    counts = Counter()
    for row in rows:
        label, pred, fallback = labels[row["id"]], row["prediction"], row["fallback"]
        counts["TP" if label and pred else "FP" if pred else "FN" if label else "TN"] += 1
        counts["reused"] += row["route"] != "fallback"
        counts["wrong_reuse"] += row["route"] != "fallback" and label != pred
        counts["fixed"] += label != fallback and label == pred
        counts["harmed"] += label == fallback and label != pred
        counts[row["route"] + "_routes"] += 1
    tp, fp, fn, tn = (counts[k] for k in ("TP", "FP", "FN", "TN"))
    return {k: counts[k] for k in ("TP", "FP", "FN", "TN", "reused", "wrong_reuse", "fixed", "harmed",
                                      "history_routes", "rule_routes", "name_cache_routes", "fallback_routes")} | {
        "n": len(rows), "precision": tp / (tp + fp) if tp + fp else 0.,
        "recall": tp / (tp + fn) if tp + fn else 0.,
        "F1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.,
        "avoided_fresh_classification_requests": counts["reused"],
        "remaining_fresh_classification_requests": counts["fallback_routes"],
        "reuse_coverage": counts["reused"] / len(rows) if rows else 0.,
    }


def run():
    protocol = read(HERE / "protocol.json")
    assert sha(__file__) == protocol["runner_sha256"]
    assert all(sha(HERE / path) == expected for path, expected in protocol["files"].items())
    records = read(HERE / "inputs/records.json")
    labels = {x["id"]: x["label"] for x in records}
    groups = protocol["groups"]
    all_rows, interventions, folds = [], [], []
    for rep in protocol["repetitions"]:
        for group, tables in groups.items():
            for seed in SEEDS:
                folder = HERE / "folds" / f"r{rep}" / group / seed
                original = fold(records, rep, tables, seed, folder)
                write(folder / "routes_and_provenance.json", original)
                for mode in ("flip", "permutation"):
                    selected = [x for x in records if x["table"] in tables]
                    values = [not x["label"] for x in selected] if mode == "flip" else [x["label"] for x in selected[1:] + selected[:1]]
                    altered = {x["id"]: value for x, value in zip(selected, values)}
                    alternative = [dict(x, label=altered.get(x["id"], x["label"])) for x in records]
                    rerun = fold(alternative, rep, tables, seed,
                                 HERE / "verification_folds" / mode / f"r{rep}" / group / seed)
                    assert original == rerun, (rep, group, seed, mode)
                    interventions.append({"repetition": rep, "group": group, "seed": seed,
                                          "mode": mode, "passed": True, "semantic_sha256": digest(original)})
                all_rows.extend(dict(x, repetition=rep, group=group) for x in original["routes"])
                folds.append({"repetition": rep, "group": group, "seed": seed,
                              "train_ids": original["train_ids"], "query_ids": original["query_ids"],
                              "correction_ids": original["correction_ids"],
                              "rule_count": len(original["rules"]["heuristics"]), "semantic_sha256": digest(original)})
    query = {"id": "TEST.X", "table": "TEST", "column": "X", "fallback": False}
    conflict = [{"id": "A.X", "table": "A", "column": "X", "label": True},
                {"id": "B.X", "table": "B", "column": "X", "label": False}]
    fixture_rule = [{"regex": "X$", "pii_type": "PII", "sample_columns": ["X"], "priority": 1}]
    assert cache_route(query, conflict, fixture_rule, True)["reason"] == "conflicting_exact_labels"
    assert cache_route(query, conflict, fixture_rule, True)["prediction"] is False
    write(HERE / "routes.json", all_rows)
    results = {"study": protocol["study"], "protocol_sha256": sha(HERE / "protocol.json"), "per_repeat": {}, "across_repeats": {}}
    for rep in protocol["repetitions"]:
        results["per_repeat"][str(rep)] = {}
        for condition in CONDITIONS:
            selected = [x for x in all_rows if x["repetition"] == rep and x["condition"] == condition]
            assert len(selected) == len({x["id"] for x in selected}) == 92
            results["per_repeat"][str(rep)][condition] = metrics(selected, labels) | {
                "fixed_ids": [x["id"] for x in selected if x["fallback"] != labels[x["id"]] == x["prediction"]],
                "harmed_ids": [x["id"] for x in selected if x["fallback"] == labels[x["id"]] != x["prediction"]],
                "per_family": {g: metrics([x for x in selected if x["group"] == g], labels) for g in groups},
            }
    for condition in CONDITIONS:
        selected = [x for x in all_rows if x["condition"] == condition]
        changing = [key for key in labels if len({x["prediction"] for x in selected if x["id"] == key}) > 1]
        deterministic = [key for key in labels if all(x["route"] != "fallback" for x in selected if x["id"] == key)]
        results["across_repeats"][condition] = {
            "classification_records": len(selected), "unique_fields": 92,
            "stable_prediction_fields": 92 - len(changing), "varying_prediction_ids": changing,
            "memory_routed_in_all_repetitions": len(deterministic),
            "fresh_model_calls_in_this_replay": 0,
        }
    write(HERE / "results.json", results)
    write(HERE / "verification.json", {"status": "pass", "label_interventions": interventions,
        "folds": folds, "routing_rows": len(all_rows), "production_methods_used": True,
        "independent_rule_differential": True, "train_only_support": True,
        "conflicting_cache_blocks_rule": True, "new_model_calls": 0, "new_participants": 0,
        "frozen_inputs_preserved": all(sha(HERE / p) == value for p, value in protocol["files"].items())})
    journal("replay_completed", routing_rows=len(all_rows), label_interventions=len(interventions),
            results_sha256=sha(HERE / "results.json"))
    print(json.dumps({rep: {c: {k: value[k] for k in ("TP", "FP", "FN", "TN", "F1", "reused", "fixed", "harmed", "fallback_routes")}
                           for c, value in rows.items()} for rep, rows in results["per_repeat"].items()}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "run"))
    parser.add_argument("--root", type=Path, default=HERE.parents[3])
    args = parser.parse_args()
    prepare(args.root) if args.command == "prepare" else run()
