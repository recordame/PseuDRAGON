#!/usr/bin/env python3
"""Frozen family-plus-name exclusion replay; no model, network, or product writes."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import logging
import os
import shutil
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
logging.disable(logging.CRITICAL)
HERE = Path(__file__).resolve().parent
RQ1 = HERE.parent
ARMS = ("name_cache", "guarded_history_rules", "guarded_cache_rules")
SETS = ("fresh_1", "fresh_2", "fresh_3", "initial_secondary")
MODES = ("family_control", "family_name_exclusion")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(HERE)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def journal(event, **values):
    with (HERE / "journal.jsonl").open("a") as stream:
        stream.write(json.dumps({"utc": datetime.now(timezone.utc).isoformat(),
                                 "event": event, **values}) + "\n")


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def prepare():
    assert not (HERE / "protocol.json").exists()
    guard = RQ1 / "20260930_history_conflict_guard"
    latest = RQ1 / "20260928_latest_source_order_reuse"
    copies = {
        "sources/expert_preference_manager.py": guard / "sources/guarded_expert_preference_manager.py",
        "sources/heuristic_pattern_learner.py": guard / "sources/heuristic_pattern_learner.py",
        "sources/canonical_pure_lookup.py": guard / "sources/canonical_pure_lookup.py",
        "replay_helpers.py": RQ1 / "20260929_reuse_parameter_sensitivity/replay_helpers.py",
        "inputs/records.json": latest / "inputs/records.json",
        "inputs/groups.json": latest / "inputs/groups.json",
        "inputs/prior_guard_routes.json": guard / "baseline_routes.json",
        "inputs/prior_fresh_routes.json": latest / "routes.json",
        "inputs/prior_initial_routes.json": RQ1 / "20260921_approved_cache_control/routes.json",
    }
    originals = {}
    for relative, original in copies.items():
        target = HERE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, target)
        originals[str(original.resolve())] = sha(original)
        assert sha(target) == sha(original)
    records = read(HERE / "inputs/records.json")
    groups = read(HERE / "inputs/groups.json")["groups"]
    initial = {row["id"]: row["fallback"] for row in read(HERE / "inputs/prior_initial_routes.json")
               if row["condition"] == "no_memory"}
    assert len(records) == len(initial) == 92
    assert sum(row["label"] for row in records) == 32
    assert len({row["column"].casefold() for row in records}) == 25
    write(HERE / "inputs/initial_fallbacks.json", initial)
    write(HERE / "input_manifest.json", originals)
    frozen = {str(path.relative_to(HERE)): sha(path) for path in HERE.rglob("*")
              if path.is_file() and path.name not in {"journal.jsonl", "protocol.json"}}
    write(HERE / "protocol.json", {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "study": "Family holdout plus complete exclusion of the query column name",
        "outcomes_at_freeze": "No outcomes of this new split computed. Prior family endpoints 75/75/83, unseen-name reuse 8/17, and partial-store WD_ACNO failures are known.",
        "arms": list(ARMS), "modes": list(MODES), "prediction_sets": list(SETS),
        "primary": list(SETS[:3]), "secondary": "initial_secondary",
        "groups": groups, "unique_fields": 92, "unique_names": 25,
        "split": "Keep each existing family holdout. For every query name in that family, additionally remove all same-name training records (case-insensitive). Fit one fresh store per family/name and prediction set. Each of 92 fields is queried exactly once per arm/set. Family control only excludes the original family.",
        "training": "Ascending table.column order; one author-reference-confirmed selection per remaining training field, plus correction history only when that set's frozen fallback disagrees. Fresh empty feedback and rule stores; invoke copied actual learner and refinement. No held-out reference label/action is passed in query objects. Simulated reference approvals, not new human decisions.",
        "sources": "Byte-identical 20260930 guarded manager and repaired learner; canonical pure unanimous lookup used by both cache arms. Existing helper builds isolated stores. Source snapshots retain their original comments.",
        "defaults": {"minimum_support": 2, "minimum_score": 0.8, "maximum_conflict": 0.1},
        "routing": "Name cache: canonical unanimous exact-name approval or fallback. Guarded history/rules: active-name conflict check, exact correction history, rules, fallback. Guarded cache/rules: same conflict check and same canonical cache; rules only after a miss. The canonical lookup receives a view excluding zero-count selections, matching the active-name guard. Fresh rebuilt stores additionally assert all selections are positive-count. All arms share identical active store/rules/fallback for a query. Static/manual rules and embeddings disabled.",
        "metrics": "Micro over 92 fields and equal-name-weighted metrics over 25 names, separately per prediction set. Report coverage, correct/wrong reuse, total errors, fixed/harmed versus frozen fallback, confusion/F1, and positive/negative strata. Name macro rates average each name's field-level rate; weighted F1 is computed from name-balanced confusion, not averaged single-class F1.",
        "controls": "Fresh-set family control must exactly reproduce guarded history and cache-plus-rules stored routes, and latest name-cache routes. Initial control must reproduce archived initial endpoint labels/routes. Each excluded-name store must contain no such name in training, exact/correction entries, or rule samples. Independent regex routing must agree with copied production lookup.",
        "repeat": "Run twice in separate output/store directories. Compare normalized snapshots, all routes, all metrics and controls byte-for-byte. Only timestamps are removed from semantic snapshots; do not strip outcomes.",
        "no_tuning": "Do not change threshold, learner, split, or fallback after outcomes. Preserve failures. Any repair of runner defects must be separately logged with old code and failed outputs retained.",
        "scope": "New offline intervention on existing institution/reference data; not new model inference, prospective field collection, human approval, cross-institution transfer, measured latency, or synthetic name augmentation. Repeated predictions are paired views, not additional independent fields.",
        "frozen_files": frozen,
    })
    journal("protocol_frozen", protocol_sha256=sha(HERE / "protocol.json"),
            new_split_outcomes_computed=False, input_files=len(originals))
    print(json.dumps({"protocol_sha256": sha(HERE / "protocol.json"), "frozen_files": len(frozen)}))


def check_frozen():
    protocol = read(HERE / "protocol.json")
    for relative, digest in protocol["frozen_files"].items():
        assert sha(HERE / relative) == digest, relative
    for path, digest in read(HERE / "input_manifest.json").items():
        assert sha(path) == digest, path
    return protocol


def summarize(rows, labels):
    def scalar(part):
        n = len(part)
        counts = Counter()
        for row in part:
            truth, pred, base = labels[row["id"]], row["prediction"], row["fallback"]
            reused = row["route"] != "fallback"
            counts["TP" if truth and pred else "FN" if truth else "FP" if pred else "TN"] += 1
            counts["reused"] += reused
            counts["correct_reuse"] += reused and pred == truth
            counts["wrong_reuse"] += reused and pred != truth
            counts["errors"] += pred != truth
            counts["harmed"] += pred != truth and base == truth
            counts["fixed"] += pred == truth and base != truth
        result = {key: counts[key] for key in ("TP", "FN", "FP", "TN", "reused", "correct_reuse", "wrong_reuse", "errors", "harmed", "fixed")}
        result.update(n=n, coverage=counts["reused"] / n if n else None,
                      wrong_reuse_rate=counts["wrong_reuse"] / n if n else None,
                      error_rate=counts["errors"] / n if n else None,
                      harmed_rate=counts["harmed"] / n if n else None,
                      fixed_rate=counts["fixed"] / n if n else None,
                      F1=2*counts["TP"]/(2*counts["TP"]+counts["FP"]+counts["FN"]) if 2*counts["TP"]+counts["FP"]+counts["FN"] else None)
        return result
    def name_weighted(part):
        names = sorted({row["column"].casefold() for row in part})
        per_name = {name: scalar([row for row in part if row["column"].casefold() == name]) for name in names}
        macro = {key: statistics.mean(value[key] for value in per_name.values()) for key in
                 ("coverage", "wrong_reuse_rate", "error_rate", "harmed_rate", "fixed_rate")} if names else {}
        confusion = {key: sum(value[key]/value["n"] for value in per_name.values()) for key in ("TP", "FP", "FN", "TN")}
        den = 2*confusion["TP"]+confusion["FP"]+confusion["FN"]
        return {"names": len(names), "names_with_any_reuse": sum(value["reused"] > 0 for value in per_name.values()),
                "names_with_wrong_reuse": sum(value["wrong_reuse"] > 0 for value in per_name.values()),
                "F1_from_name_balanced_confusion": 2*confusion["TP"]/den if den else None,
                **macro, "per_name": per_name}
    return {"field_micro": scalar(rows), "name_macro": name_weighted(rows),
            "strata": {name: {"field_micro": scalar(part), "name_macro": name_weighted(part)}
                       for name, part in (("positive", [row for row in rows if labels[row["id"]]]),
                                          ("negative", [row for row in rows if not labels[row["id"]]]))}}


def run(run_id):
    protocol = check_frozen()
    output = HERE / "runs" / run_id
    assert not output.exists(), "Preserve previous output"
    output.mkdir(parents=True)
    os.environ["MAX_PATTERN_CONFLICT_RATE"] = "0.10"
    helper = module("exclusion_helpers", HERE / "replay_helpers.py")
    helper.HERE = HERE
    canonical = module("canonical_lookup", HERE / "sources/canonical_pure_lookup.py")
    records = read(HERE / "inputs/records.json")
    initial = read(HERE / "inputs/initial_fallbacks.json")
    labels = {row["id"]: row["label"] for row in records}
    groups = protocol["groups"]
    all_rows, snapshots = [], []
    for prediction_set in SETS:
        fallback = {row["id"]: initial[row["id"]] if prediction_set == "initial_secondary" else row["fallbacks"][prediction_set[-1]] for row in records}
        for mode in MODES:
            for group, tables in groups.items():
                family_queries = [row for row in records if row["table"] in tables]
                names = sorted({row["column"].casefold() for row in family_queries}) if mode == "family_name_exclusion" else [None]
                for name in names:
                    train = [dict(row, fallback=fallback[row["id"]]) for row in records
                             if row["table"] not in tables and (name is None or row["column"].casefold() != name)]
                    train.sort(key=lambda row: row["id"])
                    removed_same_name_ids = [row["id"] for row in records if row["table"] not in tables
                                             and name is not None and row["column"].casefold() == name]
                    queries = [{key: row[key] for key in ("id", "table", "column", "comment")} | {"fallback": fallback[row["id"]]}
                               for row in family_queries if name is None or row["column"].casefold() == name]
                    assert all("label" not in row and "action" not in row for row in queries)
                    assert all(row["table"] not in tables for row in train)
                    if name is not None:
                        assert all(row["column"].casefold() != name for row in train)
                    folder = output / "stores" / prediction_set / mode / group / (name or "all_names")
                    manager, changes = helper.train_store(train, "all_selections", folder)
                    learner = manager._heuristic_learner
                    assert (learner.MIN_PATTERN_OCCURRENCES, learner.MIN_CONFIDENCE, learner.MAX_CONFLICT_RATE) == (2, .8, .1)
                    store = helper.semantic(read(folder / "feedback.json"))
                    rules = helper.semantic(read(folder / "heuristics.json"))
                    assert all(entry.get("total_selections", 1) > 0 for entry in store["column_exact"].values())
                    active_lookup_manager = SimpleNamespace(preferences={**manager.preferences, "column_exact": {
                        key: entry for key, entry in manager.preferences["column_exact"].items()
                        if entry.get("total_selections", 1) > 0}})
                    assert manager.rag_system is None and manager._embedding_generator is None and manager._column_embeddings == {}
                    assert all(rule.get("source") == "auto_learned" for rule in rules["heuristics"])
                    training_names = {row["column"].casefold() for row in train}
                    assert all({str(value).casefold() for value in rule.get("sample_columns", [])} <= training_names for rule in rules["heuristics"])
                    if name is not None:
                        assert all(entry["column_name"].casefold() != name for entry in store["column_exact"].values())
                        assert name not in {key.casefold() for key in store["pii_classification"]}
                    routed = []
                    for query in queries:
                        conflict = manager._has_active_name_label_conflict(query["column"])
                        rule_route = helper.rules_route(query, train, rules["heuristics"])
                        production_rule = manager.classify_by_heuristics(query["column"], query["comment"])
                        if not conflict:
                            assert (production_rule is None) == (rule_route["route"] == "fallback")
                            if production_rule:
                                assert (production_rule["classification"] == "PII", production_rule["pattern"]) == (rule_route["prediction"], rule_route["pattern"])
                        cache = canonical.get_learned_pii_classification(active_lookup_manager, query["column"], query["comment"])
                        history = manager.get_learned_pii_classification(query["column"], query["comment"])
                        for arm in ARMS:
                            route = helper.baseline(query)
                            if conflict or (cache and cache["match_type"] == "conflict"):
                                route["reason"] = "active_name_conflict"
                            else:
                                hit = history if arm == "guarded_history_rules" else cache
                                if hit:
                                    assert hit["match_type"] == "exact"
                                    support = [row["id"] for row in train if row["column"].casefold() == query["column"].casefold()
                                               and (arm != "guarded_history_rules" or row["id"] in changes)]
                                    route.update(prediction=hit["classification"] == "PII", route="history" if arm == "guarded_history_rules" else "name_cache",
                                                 support_ids=support, reason="exact_stored_judgment")
                                elif arm != "name_cache":
                                    route = rule_route
                            assert set(route["support_ids"]) <= {row["id"] for row in train}
                            assert route["route"] == "fallback" or route["support_ids"]
                            row = {**query, **route, "condition": arm, "prediction_set": prediction_set, "mode": mode,
                                   "group": group, "excluded_name": name}
                            routed.append(row)
                    if name is not None:
                        assert all(row["route"] not in {"history", "name_cache"} for row in routed)
                    snapshot = {"prediction_set": prediction_set, "mode": mode, "group": group, "excluded_name": name,
                                "training_ids": [row["id"] for row in train], "query_ids": [row["id"] for row in queries],
                                "removed_same_name_ids_from_family_train": removed_same_name_ids,
                                "correction_ids": changes, "store": store, "rules": rules, "routes": routed}
                    snapshots.append(snapshot)
                    all_rows.extend(routed)
            print(json.dumps({"prediction_set": prediction_set, "mode": mode, "snapshots": len(snapshots)}), flush=True)
    results = {"protocol_sha256": sha(HERE / "protocol.json"), "unique_fields": 92, "unique_names": 25,
               "new_model_calls": 0, "new_practitioner_decisions": 0, "snapshots": len(snapshots), "sets": {}}
    for prediction_set in SETS:
        results["sets"][prediction_set] = {}
        for mode in MODES:
            results["sets"][prediction_set][mode] = {}
            for arm in ARMS:
                rows = [row for row in all_rows if (row["prediction_set"], row["mode"], row["condition"]) == (prediction_set, mode, arm)]
                assert len(rows) == len({row["id"] for row in rows}) == 92
                results["sets"][prediction_set][mode][arm] = summarize(rows, labels)
    controls = []
    prior_guard = read(HERE / "inputs/prior_guard_routes.json")
    prior_fresh = read(HERE / "inputs/prior_fresh_routes.json")
    prior_initial = read(HERE / "inputs/prior_initial_routes.json")
    arm_alias = {"name_cache": "all_selections_name_cache", "guarded_history_rules": "guarded_history_rules", "guarded_cache_rules": "canonical_lookup_archived_rules"}
    initial_alias = {"name_cache": "all_approved_exact", "guarded_history_rules": "existing_exact_then_rules", "guarded_cache_rules": "all_approved_exact_then_rules"}
    for row in all_rows:
        if row["mode"] != "family_control":
            continue
        arm, prediction_set = row["condition"], row["prediction_set"]
        if prediction_set == "initial_secondary":
            old = next(item for item in prior_initial if item["id"] == row["id"] and item["condition"] == initial_alias[arm])
        elif arm == "name_cache":
            old = next(item for item in prior_fresh if item["id"] == row["id"] and item["repetition"] == int(prediction_set[-1]) and item["condition"] == arm_alias[arm])
        else:
            fold = next(item for item in prior_guard if item["rep"] == int(prediction_set[-1]) and item["group"] == row["group"])
            old = next(item for item in fold["routes"][arm_alias[arm]] if item["id"] == row["id"])
        normalize = {"approval_cache": "name_cache", "all_approved_exact": "name_cache", "exact": "history", "heuristic": "rule"}
        expected = (old["prediction"], normalize.get(old["route"], old["route"]), old.get("pattern"))
        observed = (row["prediction"], row["route"], row.get("pattern"))
        controls.append({"prediction_set": prediction_set, "condition": arm, "id": row["id"],
                         "passed": expected == observed, "expected": expected, "observed": observed})
    write(output / "snapshots.json", snapshots)
    write(output / "routes.json", all_rows)
    write(output / "results.json", results)
    write(output / "control_verification.json", {"checks": len(controls), "passed": all(row["passed"] for row in controls), "rows": controls})
    check_frozen()
    journal("run_completed", run_id=run_id, snapshots=len(snapshots), routes=len(all_rows),
            controls_passed=all(row["passed"] for row in controls), result_sha256=sha(output / "results.json"))
    assert all(row["passed"] for row in controls), "Preserved control mismatch requires investigation"


def repeat():
    check_frozen()
    files = ("snapshots.json", "routes.json", "results.json", "control_verification.json")
    comparisons = {name: {"first_sha256": sha(HERE / "runs/first" / name), "repeat_sha256": sha(HERE / "runs/repeat" / name)} for name in files}
    for value in comparisons.values():
        value["identical"] = value["first_sha256"] == value["repeat_sha256"]
    report = {"passed": all(value["identical"] for value in comparisons.values()), "comparisons": comparisons,
              "normalization": "Only source-generated timestamps removed from snapshots; routes, metrics, train/support IDs and rule contents unchanged."}
    write(HERE / "repeat_verification.json", report)
    journal("repeat_verified", passed=report["passed"], report_sha256=sha(HERE / "repeat_verification.json"))
    assert report["passed"]
    print(json.dumps(report))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "run", "verify-repeat"))
    parser.add_argument("--run-id", choices=("first", "repeat"))
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "run":
        assert args.run_id
        run(args.run_id)
    else:
        repeat()
