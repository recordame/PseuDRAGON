"""Standard-library checks independent of experiment runners and production imports."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math
import re


class AuditFailure(Exception):
    pass


def check(condition, message):
    if not condition:
        raise AuditFailure(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def records_index(records):
    result = {r['id']: r for r in records}
    check(len(result) == len(records) == 92, 'expected 92 distinct source fields')
    check(len({r['column'].lower() for r in records}) == 25, 'expected 25 distinct source names')
    check(sum(r['label'] for r in records) == 32, 'expected 32 positive source labels')
    check(all(type(r['label']) is bool for r in records), 'nonboolean source reference')
    check(all(set(r['fallbacks']) == {'1', '2', '3'} for r in records), 'expected three fixed fallback sets')
    check(all(type(x) is bool for r in records for x in r['fallbacks'].values()), 'nonboolean source fallback')
    return result


def split_ids(records, groups, group, excluded_name=None):
    held_out = {r['id'] for r in records if r['table'] in groups[group]}
    eligible = {r['id'] for r in records if r['id'] not in held_out}
    removed = {r['id'] for r in records if r['id'] in eligible and
               excluded_name is not None and r['column'].lower() == excluded_name.lower()}
    return held_out, eligible - removed, removed


def active_label_set(feedback, column):
    name = column.casefold()
    labels = set()
    for section, field in [('column_exact', 'pii_type'), ('pii_classification', 'classification')]:
        for key, entry in feedback.get(section, {}).items():
            entry_name = entry.get('column_name')
            if entry_name is None:
                entry_name = key.rsplit(':', 1)[0] if section == 'column_exact' else key
            if str(entry_name).casefold() != name:
                continue
            if section == 'column_exact' and entry.get('total_selections', 1) <= 0:
                continue
            if entry.get(field) in {'PII', 'Non-PII'}:
                labels.add(entry[field])
    return labels


def independent_route(feedback, rules, column, fallback, cache, allow_rules):
    check(type(fallback) is bool, 'fallback is not boolean')
    labels = active_label_set(feedback, column)
    base = {'prediction': fallback, 'kind': 'fallback', 'pattern': None, 'conflict': len(labels) > 1}
    if len(labels) > 1:
        return base
    if cache and labels:
        return dict(base, prediction=next(iter(labels)) == 'PII', kind='cache')
    if not cache:
        correction = feedback.get('pii_classification', {}).get(column.lower())
        if correction is not None:
            check(correction['classification'] in {'PII', 'Non-PII'}, 'invalid correction label')
            return dict(base, prediction=correction['classification'] == 'PII', kind='history')
    if allow_rules:
        active_rules = sorted([r for r in rules if r.get('enabled', True)],
                              key=lambda r: r.get('priority', 0), reverse=True)
        for rule in active_rules:
            try:
                matched = re.search(rule['regex'], column.upper(), re.IGNORECASE)
            except re.error:
                continue
            if matched:
                return dict(base, prediction=rule.get('pii_type', 'PII') == 'PII',
                            kind='rule', pattern=rule['regex'])
    return base


def audit_feedback(feedback, active_records, repetition):
    """Check aggregate current selections and correction votes from raw records."""
    selected = Counter((r['column'].lower(), 'PII' if r['label'] else 'Non-PII')
                       for r in active_records)
    actual = Counter()
    for key, entry in feedback.get('column_exact', {}).items():
        if entry.get('total_selections', 0) > 0:
            actual[(entry['column_name'].lower(), entry['pii_type'])] += entry['total_selections']
    check(selected == actual, 'feedback selections do not represent the declared active records')
    corrections = {}
    for record in active_records:
        if record['fallbacks'][str(repetition)] != record['label']:
            corrections[record['column'].lower()] = 'PII' if record['label'] else 'Non-PII'
    actual_corrections = {key: value['classification'] for key, value in feedback.get('pii_classification', {}).items()}
    check(actual_corrections == corrections, 'current correction votes differ from active-record replay')


def audit_rule_support(rules, allowed_records, excluded_name=None):
    names = {r['column'].lower() for r in allowed_records}
    for rule in rules:
        check(rule.get('source') == 'auto_learned', 'nonlearned rule in isolated store')
        samples = {x.lower() for x in rule.get('sample_columns', [])}
        check(bool(samples), 'learned rule lacks supporting sample names')
        check(samples <= names, 'rule retains a sample absent from the allowed training records')
        if excluded_name is not None:
            check(excluded_name.lower() not in samples, 'excluded query name survives in rule support')


def metric_rows(rows, source_records, repetition):
    """Each row is a field evaluation, possibly repeated across maintenance cases."""
    cells = Counter()
    by_name = defaultdict(Counter)
    for row in rows:
        source = source_records[row['id']]
        truth, pred, fallback = source['label'], row['prediction'], source['fallbacks'][str(repetition)]
        check(type(pred) is bool, 'nonboolean route prediction')
        reused = row['route'] not in {'fallback', 'llm'}
        flags = {'n': 1, 'reused': reused, 'correct_reuse': reused and pred == truth,
                 'wrong_reuse': reused and pred != truth, 'errors': pred != truth,
                 'harmed_correct_fallback': fallback == truth and pred != truth,
                 'fixed_wrong_fallback': fallback != truth and pred == truth,
                 'reference_positive': truth, 'reference_negative': not truth,
                 'reused_positive': reused and truth, 'reused_negative': reused and not truth,
                 'TP': truth and pred, 'FP': not truth and pred,
                 'FN': truth and not pred, 'TN': not truth and not pred}
        cells.update({key: int(value) for key, value in flags.items()})
        by_name[source['column'].lower()].update({key: int(value) for key, value in flags.items()})
    check(cells['reused'] == cells['correct_reuse'] + cells['wrong_reuse'], 'reuse decomposition differs')
    check(cells['n'] == sum(cells[k] for k in ['TP', 'FP', 'FN', 'TN']), 'confusion count differs')
    cells['fallback'] = cells['n'] - cells['reused']
    result = dict(cells)
    denom = 2*cells['TP'] + cells['FP'] + cells['FN']
    result['F1'] = 2*cells['TP']/denom if denom else None
    result['distinct_names'] = len(by_name)
    result['distinct_reused_names'] = sum(c['reused'] > 0 for c in by_name.values())
    result['per_name'] = {name: dict(counts) for name, counts in sorted(by_name.items())}
    result['name_equal_weighted_rates'] = {
        metric: sum(counts[metric]/counts['n'] for counts in by_name.values())/len(by_name)
        for metric in ['reused', 'correct_reuse', 'wrong_reuse', 'errors',
                       'harmed_correct_fallback', 'fixed_wrong_fallback']}
    return result


def close(actual, expected, label):
    check(isinstance(actual, (int, float)) and math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-12),
          label + ': metric mismatch')
